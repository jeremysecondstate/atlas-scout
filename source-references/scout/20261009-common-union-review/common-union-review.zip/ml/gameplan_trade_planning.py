"""Account-aware nightly review artifacts; no order or trading-control authority.

Frozen forecasts remain immutable. This separate source-bound publication adds
cash-only provisional quantities and empirical entry-price planning ranges.
The existing live worker still revalidates ownership, cash and its ask LIMIT.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from decimal import Decimal, ROUND_CEILING
from pathlib import Path
from typing import Mapping

import pandas as pd

from ml.artifacts import create_timestamp_directory, file_checksum, verify_manifest, write_manifest, utc_timestamp
from ml.stock_trader.contracts import PredictionSignal, StockTraderPolicy, finite, utc
from ml.stock_trader.fixed_horizon_budget import FIXED_HORIZON_WEIGHTS, fixed_budget_forecast_readiness
from ml.stock_direction_policy import BULLISH_PROBABILITY, BEARISH_PROBABILITY, STOCK_DIRECTION_POLICY_VERSION


VERSION = "cash-aware-gameplan-trade-planning-v4"
AUTHORITY = "REVIEW_ONLY_REVALIDATE_AT_ENTRY"
PLANNING_PRICE_LOOKBACK_SESSIONS = 504
PRODUCER_MODE = "ACCOUNT_PRODUCER_SOURCE"
RESEARCH_PRODUCER_MODE = "RESEARCH_PRODUCER_SOURCE"
SHARED_PROJECTION_UNAVAILABLE = "UNAVAILABLE_SHARED_ACCOUNT_PROJECTION"


def _planning_snapshot(snapshot: Mapping) -> tuple[dict, dict | None]:
    """Use fresh broker state for review planning when only a stale local buy
    reservation prevents the ownership ledger from being marked ready.

    This is deliberately planning-only.  The immutable account artifact keeps
    the original ownership evidence, while the live trader continues to
    reconcile its ledger and broker state before any order decision.
    """
    ownership = snapshot.get("ownership", {})
    reasons = set(ownership.get("reason_codes", ()))
    pending_buys = snapshot.get("pending_buy_shares", {})
    broker_has_no_pending_buys = not any(_money(value) for value in pending_buys.values())
    if (ownership.get("safe_for_planning") is True
            or reasons != {"PENDING_LEDGER_RESERVATIONS_REQUIRE_RECONCILIATION"}
            or snapshot.get("working_order_count") != 0
            or not broker_has_no_pending_buys):
        return dict(snapshot), None
    planning = dict(snapshot)
    planning_ownership = dict(ownership)
    planning_ownership["safe_for_planning"] = True
    planning_ownership["status"] = "OBSERVED_CONSISTENT_FOR_REVIEW"
    planning_ownership["reason_codes"] = []
    planning_ownership["planning_override"] = "CURRENT_BROKER_HAS_ZERO_WORKING_ORDERS_AND_ZERO_PENDING_BUYS"
    # Do not let a stale local BUY reservation suppress a new informational
    # plan.  This does not mutate the ledger or grant execution authority.
    planning_ownership["active_allocations"] = [
        {**allocation, "reserved_buy_shares": 0}
        for allocation in ownership.get("active_allocations", [])
    ]
    planning["ownership"] = planning_ownership
    return planning, {"type": "STALE_LOCAL_BUY_RESERVATION_IGNORED_FOR_REVIEW",
                      "basis": planning_ownership["planning_override"]}


def _money(value: object) -> Decimal:
    number = Decimal(str(value))
    if not number.is_finite() or number < 0:
        raise ValueError("Trade planning requires nonnegative finite monetary inputs")
    return number


def _signal(row: Mapping) -> PredictionSignal:
    return PredictionSignal(
        symbol=str(row["symbol"]), primary_horizon=str(row["model_group"]),
        prediction_id=str(row["id"]), decision_timestamp=str(row["decision_timestamp"]),
        target_window_start=str(row["target_window_start"]), target_window_end=str(row["target_window_end"]),
        actionable_until=str(row["target_window_end"]), prediction_created_at=str(row["frozen_at"]),
        calibrated_probability=float(row["calibrated_probability"]), assumed_round_trip_cost=0.,
        horizon_probabilities={}, model_name=str(row["model_family"]), model_version=str(row["model_artifact"]),
        source_fingerprint="verified-publication-review", target_definition_version=str(row["target_contract_version"]),
        target_price_source_contract=str(row["target_price_source_contract"]),
    )


def plan_trade_rows(forecasts: pd.DataFrame, snapshot: Mapping, bands: Mapping,
                    *, policy: StockTraderPolicy | None = None) -> pd.DataFrame:
    """Reserve provisional BUY capacity once, without assuming future sale proceeds.

The sizing rule mirrors the selected fixed-confidence budget. Entry-window and
live-control checks are deliberately not simulated; these are review proposals,
not executable TradeDecisions. A shared ledger of planned dollars prevents the
same current cash being promised to several horizons or symbols.
"""
    from ml.gameplan_cash_ledger import _planning_direction

    policy = policy or StockTraderPolicy()
    policy.validate()
    data = forecasts.copy()
    if data.empty or data.id.duplicated().any():
        raise ValueError("Trade planning requires unique frozen forecast rows")
    band_rows = {str(row.get("forecast_id", row.get("id"))): row for row in bands["rows"]}
    if len(bands["rows"]) != len(data) or len(band_rows) != len(data) or set(band_rows) != set(data.id.astype(str)):
        raise ValueError("Price bands differ from the frozen forecast identities")
    ownership = snapshot.get("ownership", {})
    active = {(str(row["symbol"]), str(row["horizon"])) for row in ownership.get("active_allocations", [])}
    blocked_symbols = set(ownership.get("blocked_symbols", []))
    evidence_ready = (snapshot.get("status") == "OBSERVED" and snapshot.get("cash_status") == "CASH_ONLY_BOUNDED"
                      and ownership.get("safe_for_planning") is True)
    try:
        equity = _money(snapshot["account_equity"])
        cash = _money(snapshot["available_cash"]) * _money(policy.maximum_cash_utilization_fraction)
        gross = equity * _money(policy.maximum_gross_equity_fraction) - _money(snapshot["gross_exposure"])
        pending = {}
        for symbol, quantity in snapshot.get("pending_buy_shares", {}).items():
            if _money(quantity):
                ask = _money(snapshot["quotes"][symbol]["ask"])
                if not ask:
                    raise ValueError("A working buy has no price")
                pending[symbol] = _money(quantity) * ask
        # Account-wide BUY/debit reservations can include symbols or assets
        # outside this forecast universe. They consume gross headroom too.
        gross -= max(sum(pending.values(), Decimal(0)), _money(snapshot["reserved_cash"]))
        available = max(Decimal(0), min(cash, gross))
        remaining = {symbol: max(Decimal(0), equity * _money(policy.maximum_symbol_equity_fraction)
                     - _money(snapshot["symbol_exposure"][symbol]) - pending.get(symbol, Decimal(0)))
                     for symbol in data.symbol.unique()}
        if equity <= 0:
            evidence_ready = False
    except (ArithmeticError, TypeError, KeyError, ValueError):
        evidence_ready = False
        equity = available = Decimal(0)
        remaining = {}
    # Each projection is the account's affordable horizon allocation for one
    # opportunity. It is not conditional on the entry signal being bullish and
    # is not summed as a batch of simultaneous orders. Scheduled entries below
    # retain a separate shared reservation ledger and confidence-weighted size.
    projection_available, projection_remaining = available, remaining.copy()
    ordered = data.sort_values(["target_window_start", "calibrated_probability", "symbol", "model_group"],
                               ascending=[True, False, True, True], kind="stable")
    planned_horizons = set()
    batch_counts: dict[str, int] = {}
    results = {}
    for row in ordered.to_dict("records"):
        symbol, horizon = str(row["symbol"]), str(row["model_group"])
        band = band_rows[str(row["id"])]
        quote = snapshot.get("quotes", {}).get(symbol, {})
        quote_freshness_anchor = (band.get("price_reference_effective_at")
                                  if band.get("price_reference_is_synthetic")
                                  else band.get("price_reference_observed_at"))
        result = {**row, **{key: value for key, value in band.items() if key not in row},
                  "trade_quantity": 0, "trade_action": "NO_TRADE", "trade_planning_authority": AUTHORITY,
                  "trade_planning_reason": "NON_ENTRY_CONTEXT", "trade_notional_reserved": 0.,
                  "trade_budget_before_cash_caps": 0., "trade_limit_price_reference": None,
                  "account_snapshot_at": snapshot.get("observed_at"),
                  "current_held_shares": snapshot.get("held_shares", {}).get(symbol),
                  "current_symbol_investment": snapshot.get("symbol_exposure", {}).get(symbol),
                  "cash_available_at_planning": snapshot.get("available_cash"),
                  "broker_price_reference": quote.get("price_reference"),
                  "broker_price_reference_time": quote.get("price_reference_time"),
                  "planning_direction": _planning_direction(row),
                  "projected_trade_quantity": None, "projected_trade_budget": None,
                  "projected_trade_notional": None, "projected_quantity_reason": "NON_ENTRY_CONTEXT"}
        if row["execution_eligible"]:
            result["projected_quantity_reason"] = "ACCOUNT_EVIDENCE_UNAVAILABLE"
            if evidence_ready:
                result["projected_quantity_reason"] = "PRICE_RANGE_UNAVAILABLE"
                if band.get("price_band_status") == "AVAILABLE":
                    high = _money(band["trade_price_high"]).quantize(
                        Decimal(1).scaleb(-policy.price_decimals), rounding=ROUND_CEILING)
                    if high > 0:
                        ceiling = equity * min(
                            _money(policy.maximum_symbol_equity_fraction) * FIXED_HORIZON_WEIGHTS[horizon] / 10,
                            _money(policy.maximum_single_order_equity_fraction))
                        budget = max(Decimal(0), min(ceiling, projection_available, projection_remaining[symbol]))
                        projected = int(budget / high)
                        if projected * high < _money(policy.minimum_order_notional):
                            projected = 0
                        result.update(projected_trade_quantity=projected, projected_trade_budget=float(budget),
                                      projected_trade_notional=float(projected * high),
                                      projected_quantity_reason="AFFORDABLE_HORIZON_ALLOCATION" if projected else "INSUFFICIENT_WHOLE_SHARE_CAPACITY")
            ready = fixed_budget_forecast_readiness(_signal(row), forecast_promoted=row["model_status"] == "PROMOTED", policy=policy)
            code = str(ready["reason"])
            if ready.get("entry_signal"):
                code = "PROVISIONAL_BUY"
                if finite(row.get("symbol_route_fitted_target_rows"), default=0) <= 0:
                    code = "NO_EXACT_ROUTE_FITTED_HISTORY"
                elif not evidence_ready or symbol in blocked_symbols:
                    code = "ACCOUNT_OR_OWNERSHIP_EVIDENCE_UNAVAILABLE"
                elif (symbol, horizon) in active:
                    code = "HORIZON_ALLOCATION_ALREADY_ACTIVE"
                elif (symbol, horizon) in planned_horizons:
                    code = "REQUIRES_PRIOR_EXIT_CONFIRMATION"
                elif not all(finite(quote.get(k)) is not None for k in ("bid", "ask", "price_reference")) or not 0 < quote["bid"] <= quote["ask"]:
                    code = "QUOTE_REFERENCE_UNAVAILABLE"
                elif (quote["ask"] - quote["bid"]) / ((quote["ask"] + quote["bid"]) / 2) > policy.maximum_extended_relative_spread:
                    code = "QUOTE_REFERENCE_SPREAD_TOO_WIDE"
                elif not quote.get("price_reference_time") or not quote_freshness_anchor:
                    code = "QUOTE_REFERENCE_TIME_UNAVAILABLE"
                elif not (utc(quote_freshness_anchor) - pd.Timedelta(minutes=5)
                          <= utc(quote["price_reference_time"]) <= utc(snapshot["observed_at"])):
                    code = "QUOTE_REFERENCE_STALE_OR_FUTURE"
                if code == "PROVISIONAL_BUY":
                    tick = Decimal(1).scaleb(-policy.price_decimals)
                    ask = _money(quote["ask"]).quantize(tick, rounding=ROUND_CEILING)
                    # Estimated planning ranges describe a scenario, never an
                    # acceptable execution-price boundary. This preview sizes
                    # and reserves against its observed ask; live execution
                    # obtains a new quote and actual available cash each time.
                    if (ask / _money(quote["ask"]) - 1) * 10000 > Decimal(str(policy.maximum_limit_offset_bps)):
                        code = "LIMIT_REFERENCE_ROUNDING_EXCEEDS_CAP"
                    else:
                        ceiling = equity * min(_money(policy.maximum_symbol_equity_fraction) * FIXED_HORIZON_WEIGHTS[horizon] / 10,
                                               _money(policy.maximum_single_order_equity_fraction))
                        confidence = min(Decimal("0.5"), max(Decimal(0), 2 * Decimal(str(row["calibrated_probability"])) - 1))
                        budget = ceiling * confidence
                        result["trade_budget_before_cash_caps"] = float(budget)
                        quantity = int(max(Decimal(0), min(budget, available, remaining[symbol])) / ask)
                        batch = utc(row["target_window_start"]).isoformat()
                        if batch_counts.get(batch, 0) >= min(6, policy.maximum_orders_per_wake):
                            code = "COMBINED_BATCH_ORDER_CAP"
                        elif quantity < 1 or quantity * ask < _money(policy.minimum_order_notional):
                            code = "INSUFFICIENT_WHOLE_SHARE_BUDGET"
                        else:
                            notional = quantity * ask
                            result.update(trade_quantity=quantity, trade_action="PROVISIONAL_BUY", trade_notional_reserved=float(notional),
                                          trade_limit_price_reference=float(ask))
                            available -= notional
                            remaining[symbol] -= notional
                            planned_horizons.add((symbol, horizon))
                            batch_counts[batch] = batch_counts.get(batch, 0) + 1
            result["trade_planning_reason"] = code
        result["scheduled_trade_quantity"] = result["trade_quantity"]
        results[str(row["id"])] = result
    return pd.DataFrame([results[str(identifier)] for identifier in data.id])


def _write_json(path: Path, value: Mapping) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, default=str, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def _plan_working_price_rows(forecasts: pd.DataFrame, snapshot: Mapping,
                             historical_bands: Mapping, price_path: Mapping,
                             *, policy: StockTraderPolicy) -> pd.DataFrame:
    """Keep the scheduled preview and recompute capacity at conditional prices.

    The scheduled preview uses its observed quote, independent of either
    historical or working ranges. The separate per-opportunity capacity and
    displayed working prices use the empirical-median path; neither
    calculation grants execution authority.
    """
    scheduled = plan_trade_rows(forecasts, snapshot, historical_bands, policy=policy)
    forecast_rows = {str(row["id"]): row for row in forecasts.to_dict("records")}
    working_rows = []
    for original in historical_bands["rows"]:
        row = dict(original)
        forecast = forecast_rows[str(row.get("forecast_id", row.get("id")))]
        row.update(historical_price_low=original.get("trade_price_low"),
                   historical_price_high=original.get("trade_price_high"),
                   historical_price_band_status=original.get("price_band_status"),
                   historical_price_band_reason=original.get("price_band_reason"),
                   price_band_reason=original.get("price_band_reason"),
                   trade_price_low=None, trade_price_mid=None, trade_price_high=None,
                   planning_price_point_key=None, planning_price_method=None)
        if forecast["execution_eligible"]:
            start = utc(forecast["target_window_start"])
            local = start.tz_convert("America/Los_Angeles")
            key = f"{forecast['symbol']}|{local.date().isoformat()}|{local:%H:%M}"
            point = price_path["points"].get(key)
            row["planning_price_point_key"] = key
            row["price_band_status"] = "UNAVAILABLE_PLANNING_PRICE_POINT"
            row["price_band_reason"] = "No exact conditional working price for the target entry"
            if point is not None:
                if (point.get("symbol") != forecast["symbol"]
                        or utc(point["timestamp"]) != start
                        or point.get("action_date") != local.date().isoformat()
                        or point.get("clock_local") != local.strftime("%H:%M")):
                    raise ValueError("Planning price point differs from the frozen target entry")
                row.update(price_band_status=point["status"], price_band_reason=point["reason"],
                           planning_price_method=point["method"])
                if point["status"] == "AVAILABLE":
                    low, mid, high = (_money(point[field]) for field in
                                      ("planned_price_low", "planned_price_mid", "planned_price_high"))
                    if not 0 < low <= mid <= high:
                        raise ValueError("Conditional working prices are invalid")
                    row.update(trade_price_low=float(low), trade_price_mid=float(mid), trade_price_high=float(high))
        working_rows.append(row)
    working_bands = {**historical_bands, "rows": working_rows}
    working = plan_trade_rows(forecasts, snapshot, working_bands, policy=policy)
    scheduled["scheduled_trade_price_low"] = scheduled["trade_price_low"]
    scheduled["scheduled_trade_price_high"] = scheduled["trade_price_high"]
    fields = ["trade_price_low", "trade_price_mid", "trade_price_high", "price_band_status", "price_band_reason",
              "historical_price_low", "historical_price_high", "historical_price_band_status", "historical_price_band_reason",
              "planning_price_point_key", "planning_price_method", "projected_trade_quantity", "projected_trade_budget",
              "projected_trade_notional", "projected_quantity_reason"]
    for field in fields:
        scheduled[field] = working[field]
    return scheduled


def _review_refresh_basis(root, prior_run, source, source_hash, action_date, now):
    """Pin an existing informational review; never acquire a new broker state."""
    prior = (root / prior_run).resolve()
    if prior.parent != (root / "ml/gameplan-trade-plan-runs").resolve():
        raise ValueError("Review refresh must use an existing trade-plan run")
    pointer_path = root / "ml/gameplan-trade-plan-latest/run.json"
    pointer_hash = file_checksum(pointer_path)
    pointer = json.loads(pointer_path.read_text(encoding="utf-8"))
    current = pointer.get("current", {})
    receipt_hash = file_checksum(prior / "receipt.json")
    receipt = json.loads((prior / "receipt.json").read_text(encoding="utf-8"))
    manifest = verify_manifest(prior)
    report = json.loads((prior / "report.json").read_text(encoding="utf-8"))
    config = manifest.get("configuration", {})
    if (pointer.get("schema_version") != VERSION or current.get("run_path") != prior.relative_to(root).as_posix()
            or current.get("receipt_sha256") != receipt_hash
            or receipt.get("manifest_sha256") != file_checksum(prior / "manifest.json")
            or receipt.get("run_path") != prior.relative_to(root).as_posix()
            or any(item.get("schema_version") != VERSION or item.get("action_date") != action_date
                   or item.get("source_gameplan_run") != source.relative_to(root).as_posix()
                   or item.get("source_receipt_sha256") != source_hash
                   or item.get("execution_authority") != AUTHORITY
                   or item.get("broker_orders_enabled") is not False or item.get("orders_placed") != 0
                   for item in (receipt, report, config))
            or any(item.get("status") != "COMPLETE" for item in (receipt, report))
            or current.get("source_receipt_sha256") != source_hash or current.get("action_date") != action_date):
        raise ValueError("Review refresh requires the complete current review of these exact frozen forecasts")
    snapshot = json.loads((prior / "account-snapshot.json").read_text(encoding="utf-8"))
    price_path = json.loads((prior / "planning-price-path.json").read_text(encoding="utf-8"))
    asof = utc(price_path["observed_at"])
    if snapshot != report.get("snapshot") or not utc(snapshot["observed_at"]) <= asof <= utc(receipt["completed_at"]) <= now:
        raise ValueError("Review refresh requires consistent original snapshot and planning clocks")
    evidence = {"base_run": prior.relative_to(root).as_posix(), "base_receipt_sha256": receipt_hash,
                "refreshed_at": now.isoformat(), "account_snapshot_observed_at": snapshot["observed_at"],
                "planning_price_asof": asof.isoformat(), "source_forecasts_unchanged": True,
                "purpose": "Recalculate informational planning estimates from the original account snapshot and as-of cutoff"}
    inputs = [prior / name for name in ("receipt.json", "manifest.json", "report.json", "account-snapshot.json", "planning-price-path.json")]
    return snapshot, asof, evidence, inputs, pointer_hash


def _publish_producer_prices(root, publication, forecasts, intents, *, binding, observed, deadline_at,
                             price_loader, clock, fallback_metadata, probability_metadata,
                             original_deadline=None, late_action_date=None, research_producer_only=False):
    """Save observed planning estimates without reading a producer's account ledger."""
    from ml.account_gameplan.config import load_account_config
    from ml.stock_target_prices import load_stock_target_prices
    from ml.gameplan_price_bands import build_entry_price_bands, build_planning_price_path
    source, config = publication.run_directory, publication.manifest["configuration"]
    source_hash = file_checksum(source / "receipt.json")
    day = publication.receipt["action_date"]
    latest_pointer = root / "ml/gameplan-trade-plan-latest/run.json"
    previous_pointer = latest_pointer.read_bytes() if latest_pointer.exists() else None
    committed_pointer = None
    run = create_timestamp_directory(root / "ml/gameplan-trade-plan-runs", timestamp=observed)
    metadata = {"schema_version": VERSION, "action_date": day, **fallback_metadata, **probability_metadata,
        "publication_mode": RESEARCH_PRODUCER_MODE if research_producer_only else PRODUCER_MODE,
        "account_config_sha256": None if research_producer_only else binding.fingerprint,
        "holding_policy": "accumulate_bullish_sell_on_bearish_no_scheduled_expiry_v1",
        "producer_id": "scout" if research_producer_only else binding.machine_id,
        "symbols": list(config["symbols"]), "source_gameplan_run": source.relative_to(root).as_posix(),
        "source_receipt_sha256": source_hash, "orders_placed": 0, "broker_orders_enabled": False,
        "execution_authority": AUTHORITY}
    report = {**metadata, "status": "RUNNING", "observed_at": observed.isoformat(),
              "deadline_at": (original_deadline if original_deadline is not None else deadline_at).isoformat(),
              "effective_deadline_at": deadline_at.isoformat()}
    if late_action_date is not None:
        metadata.update(late_action_date=late_action_date, preparation_mode="LATE_RECOVERY")
        report.update(late_action_date=late_action_date, preparation_mode="LATE_RECOVERY")
    def binding_unchanged():
        return research_producer_only or load_account_config(root) == binding
    try:
        prices, files, inventory = (price_loader or load_stock_target_prices)(root,
            symbols=tuple(config["symbols"]), source_contract=config["target_price_source_contract"])
        asof = utc(clock())
        bands = build_entry_price_bands(prices, forecasts, observed_at=asof,
            lookback_sessions=PLANNING_PRICE_LOOKBACK_SESSIONS,
            allow_reference_forward_fill=True, allow_sparse_session_references=True)
        path = build_planning_price_path(prices, forecasts, observed_at=asof, entry_bands=bands,
            allow_reference_forward_fill=True, allow_sparse_session_references=True)
        bands_by_id = {row["forecast_id"]: row for row in bands["rows"]}
        if set(bands_by_id) != set(forecasts.id) or len(bands["rows"]) != len(forecasts):
            raise ValueError("Producer price bands differ from frozen forecasts")
        records = []
        for forecast in forecasts.to_dict("records"):
            band = bands_by_id[forecast["id"]]
            row = {**forecast, **{key: value for key, value in band.items() if key.startswith("price_")},
                   "historical_price_low": band.get("trade_price_low"), "historical_price_high": band.get("trade_price_high"),
                   "trade_price_low": None, "trade_price_mid": None, "trade_price_high": None,
                   "trade_planning_reason": SHARED_PROJECTION_UNAVAILABLE, "projected_quantity_reason": SHARED_PROJECTION_UNAVAILABLE}
            if forecast["execution_eligible"]:
                start = utc(forecast["target_window_start"])
                local = start.tz_convert("America/Los_Angeles")
                key = f"{forecast['symbol']}|{local.date().isoformat()}|{local:%H:%M}"
                point = path["points"][key]
                if point["symbol"] != forecast["symbol"] or utc(point["timestamp"]) != start:
                    raise ValueError("Producer working price differs from the exact frozen entry")
                row.update(planning_price_point_key=key, planning_price_method=point.get("method"),
                           price_band_status=point["status"], price_band_reason=point["reason"])
                if point["status"] == "AVAILABLE":
                    low, mid, high = (_money(point[f"planned_price_{part}"]) for part in ("low", "mid", "high"))
                    if not 0 < low <= mid <= high:
                        raise ValueError("Producer working price range is invalid")
                    row.update(trade_price_low=float(low), trade_price_mid=float(mid), trade_price_high=float(high))
            for field in ("trade_quantity", "scheduled_trade_quantity", "projected_trade_quantity", "trade_notional_reserved",
                          "projected_trade_budget", "projected_trade_notional", "direction_based_trade_quantity",
                          "direction_based_action", "direction_based_reason", "projected_cash_after_low",
                          "projected_cash_after_base", "projected_cash_after_high", "projected_shares_after"):
                row[field] = None
            records.append(row)
        rows = pd.DataFrame(records)
        ledger = {**fallback_metadata, "status": SHARED_PROJECTION_UNAVAILABLE, "events": [], "hourly": [],
            "ending_positions": {}, "summary": {}, "orders_placed": 0, "broker_orders_enabled": False,
            "holding_policy": "accumulate_bullish_sell_on_bearish_no_scheduled_expiry_v1",
            "reason": "This producer prepares frozen prices only. Shared cash and holdings are projected once by the account coordinator."}
        completion = bands["reference_completion"]
        synthetic = pd.DataFrame(completion["synthetic_bars"])
        if synthetic.empty:
            synthetic = pd.DataFrame(columns=["symbol", "timestamp", "open", "high", "low", "close", "volume", "is_synthetic", "reason", "original_observed_at"])
        synthetic.to_parquet(run / "synthetic-reference-bars.parquet", index=False)
        rows.to_parquet(run / "trade-plan.parquet", index=False)
        report.update(status="COMPLETE", completed_at=utc(clock()).isoformat(), forecast_rows=len(rows),
            rows_by_symbol=rows.groupby("symbol").size().to_dict(), option_intent_rows=len(intents),
            snapshot=None, snapshot_status="NOT_CAPTURED_PRODUCER_ONLY", direction_projection_status=SHARED_PROJECTION_UNAVAILABLE,
            direction_based_projection=ledger, source_price_inventory=inventory,
            target_price_source_contract=config["target_price_source_contract"],
            reference_completion={key: value for key, value in completion.items() if key != "synthetic_bars"})
        for name, payload in (("price-bands.json", bands), ("planning-price-path.json", path),
                              ("planning-reference-completion.json", completion), ("direction-ledger.json", ledger), ("report.json", report)):
            _write_json(run / name, payload)
        lines = [f"# Producer price preparation — {day}", "", ledger["reason"], "",
                 "No account snapshot, cash projection, holdings assignment, or trade quantity was calculated here.", "",
                 "| Symbol | Horizon | Original forecast | Model status | P(up) | Working price low | Mid | High |",
                 "|---|---|---|---|---:|---:|---:|---:|"]
        for row in records:
            cells = [row["symbol"], row["model_group"], row["id"], row["model_status"], row["calibrated_probability"],
                     *(row[f"trade_price_{part}"] for part in ("low", "mid", "high"))]
            lines.append("| " + " | ".join("—" if value is None else str(value).replace("|", "\\|") for value in cells) + " |")
        lines += ["", "Working ranges retain the saved historical assumptions and observed timestamps. Carried closes are disclosed below.", ""]
        for reference in completion.get("references", {}).values():
            if reference.get("status") == "AVAILABLE_SYNTHETIC":
                lines.append(f"- {reference['symbol']}: observed {reference['observed_at']}; effective {reference['effective_at']}; assumed carry {reference['gap_minutes']} minutes.")
        lines += ["", "Full historical carry evidence: planning-reference-completion.json; exact bars: synthetic-reference-bars.parquet."]
        (run / "Gameplan.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
        outputs = ["trade-plan.parquet", "price-bands.json", "planning-price-path.json", "planning-reference-completion.json",
                   "synthetic-reference-bars.parquet", "direction-ledger.json", "report.json", "Gameplan.md"]
        write_manifest(run, run_timestamp=observed, input_files=[source / "receipt.json", source / "manifest.json",
            source / "forecasts.parquet", *files], output_files=outputs, configuration=metadata, datastore_root=root)
        verify_manifest(run)
        terminal = {**metadata, "status": "COMPLETE", "run_path": run.relative_to(root).as_posix(),
            "manifest_sha256": file_checksum(run / "manifest.json"), "forecast_rows": len(rows), "completed_at": utc(clock()).isoformat()}
        if (utc(clock()) >= deadline_at or file_checksum(source / "receipt.json") != source_hash
                or not binding_unchanged()):
            raise ValueError("Producer preparation source, binding or original deadline changed")
        _write_json(run / "receipt.json", terminal)
        if utc(clock()) >= deadline_at or not binding_unchanged():
            raise ValueError("Producer preparation deadline or binding changed before publication")
        if (latest_pointer.read_bytes() if latest_pointer.exists() else None) != previous_pointer:
            raise ValueError("Producer price-plan pointer advanced independently")
        pointer_document = {"schema_version": VERSION, "current": {
            "run_path": terminal["run_path"], "action_date": day, "source_receipt_sha256": source_hash,
            "receipt_sha256": file_checksum(run / "receipt.json")}}
        _write_json(latest_pointer, pointer_document)
        # Capture the exact owned bytes only if the installed value is still
        # ours; a competing writer's pointer is never rollback material.
        written_bytes = latest_pointer.read_bytes()
        if json.loads(written_bytes) == pointer_document:
            committed_pointer = written_bytes
        if committed_pointer is None:
            raise ValueError("Producer price-plan pointer advanced during publication")
        if (utc(clock()) >= deadline_at or not binding_unchanged()
                or file_checksum(source / "receipt.json") != source_hash or latest_pointer.read_bytes() != committed_pointer):
            raise ValueError("Producer price-plan deadline, source or binding changed during publication")
        return run
    except Exception as exc:
        if committed_pointer is not None and latest_pointer.exists() and latest_pointer.read_bytes() == committed_pointer:
            # The native owner holds the trade-planning lock. Restore only its
            # exact just-written bytes; retain the failed run for inspection.
            if previous_pointer is None:
                latest_pointer.unlink()
            else:
                import uuid
                temporary = latest_pointer.with_name(latest_pointer.name + f".producer-rollback-{uuid.uuid4().hex}.tmp")
                try:
                    temporary.write_bytes(previous_pointer)
                    if latest_pointer.read_bytes() == committed_pointer:
                        temporary.replace(latest_pointer)
                finally:
                    temporary.unlink(missing_ok=True)
        report.update(status="FAILED", failure_code="PRODUCER_PRICE_PREPARATION_FAILED", failure_type=type(exc).__name__)
        _write_json(run / "report.json", report)
        _write_json(run / "receipt.json", {"schema_version": VERSION, "status": "FAILED", "orders_placed": 0,
            "broker_orders_enabled": False, "report_sha256": file_checksum(run / "report.json")})
        raise RuntimeError(f"Producer price preparation failed; review {run / 'report.json'}") from None


def publish_trade_plan(datastore_root: Path, *, gameplan_run: Path, deadline: object | None = None,
                       snapshot_loader=None, price_loader=None, clock=utc_timestamp,
                       deadline_exception: Path | None = None, refresh_plan: Path | None = None,
                       account_producer_only: bool = False, expected_account_config: str | None = None,
                       late_action_date: str | None = None, research_producer_only: bool = False) -> Path:
    """Publish a separate immutable account/price review for one verified Gameplan."""
    from ml.nightly_gameplan import read_gameplan_run
    from ml.stock_trader.independent_signals import _validated_independent_forecasts, verified_promoted_model_groups, late_publication_time
    from ml.stock_target_prices import load_stock_target_prices
    from ml.gameplan_price_bands import build_entry_price_bands, build_planning_price_path
    from ml.gameplan_cash_ledger import project_direction_trades, UnavailablePlanningPricePath
    from ml.gameplan_trade_snapshot import capture_trade_planning_snapshot
    from ml.gameplan_trade_review import render_trade_review
    from ml.gameplan_actuals_review import previous_action_date

    root = Path(datastore_root).resolve()
    if research_producer_only and (account_producer_only or expected_account_config is not None
                                 or snapshot_loader is not None or refresh_plan is not None):
        raise ValueError("Research-only preparation cannot capture an account or combine producer modes")
    binding = None
    if account_producer_only:
        from ml.account_gameplan.config import load_account_config
        binding = load_account_config(root)
        if (binding is None or binding.fingerprint != expected_account_config
                or deadline_exception is not None or refresh_plan is not None or snapshot_loader is not None):
            raise ValueError("Producer-only preparation requires its exact account binding and original deadline, without account snapshots")
    elif expected_account_config is not None:
        raise ValueError("Account producer binding requires explicit producer-only mode")
    publication = read_gameplan_run(root, Path(gameplan_run))
    source = publication.run_directory
    config = publication.manifest["configuration"]
    from ml.gameplan_probability_target import probability_target_contract, probability_target_metadata
    probability_metadata = probability_target_metadata(probability_target_contract(config))
    if config.get("preparation_scope") != "STOCK_ONLY" or config.get("target_contract_version") != "independent-stock-targets-v1":
        raise ValueError("Trade planning requires the explicit independent stock-only Gameplan")
    action_date = str(publication.receipt["action_date"])
    from ml.stock_trader.cross_horizon_fallback import validate_fallback_policy
    fallback_policy = validate_fallback_policy(config.get("cross_horizon_fallback_policy"), action_date)
    fallback_metadata = {"cross_horizon_fallback_policy": fallback_policy} if fallback_policy is not None else {}
    source_receipt_hash = file_checksum(source / "receipt.json")
    expected_deadline = pd.Timestamp(action_date).tz_localize("America/Los_Angeles") + pd.Timedelta(hours=4)
    deadline_at = utc(deadline) if deadline is not None else expected_deadline.tz_convert("UTC")
    observed = utc(clock())
    original_deadline = expected_deadline.tz_convert("UTC")
    if late_action_date is not None:
        close = (expected_deadline + pd.Timedelta(hours=13)).tz_convert("UTC")
        if (late_action_date != action_date
                or config.get("publication_mode") != "LATE_RECOVERY"
                or config.get("late_action_date") != action_date
                or deadline is None or refresh_plan is not None
                or observed < original_deadline
                or (deadline_exception is not None and not Path(deadline_exception).is_file())
                or (deadline_exception is None and observed >= deadline_at)
                or not original_deadline <= deadline_at <= close):
            raise ValueError("Late trade planning requires the matching recovery source and unexpired recovery deadline")
    elif deadline_at != original_deadline:
        # A saved planning-tail continuation retains its original recovery
        # cutoff even when its accepted forecast was published before 04:00.
        # preparation_deadline below verifies the exact source receipt, both
        # original deadlines and the explicit, fixed continuation window.
        from ml.preparation_deadline import RECOVERY_VERSION
        if (deadline_exception is None or not Path(deadline_exception).is_file()
                or json.loads(Path(deadline_exception).read_text(encoding="utf-8")).get("schema_version") != RECOVERY_VERSION):
            raise ValueError("Trade planning deadline differs from the pinned action session")
    from ml.preparation_deadline import preparation_deadline
    refresh_snapshot = refresh_asof = refresh_evidence = refresh_pointer_hash = None
    refresh_inputs = []
    if late_action_date is not None or (deadline_at != original_deadline and refresh_plan is None):
        deadline_at, exception_evidence = preparation_deadline(root, source, deadline_at, observed, deadline_exception)
    elif refresh_plan is None:
        deadline_at, exception_evidence = preparation_deadline(root, source, original_deadline, observed, deadline_exception)
    else:
        if deadline_exception is not None or snapshot_loader is not None:
            raise ValueError("Informational refresh reuses its saved snapshot and cannot extend preparation exceptions")
        session_start = pd.Timestamp(action_date).tz_localize("America/Los_Angeles").tz_convert("UTC")
        deadline_at = session_start + pd.Timedelta(hours=17)
        if not session_start <= observed < deadline_at:
            raise ValueError("Informational refresh must occur on the action date before 17:00 Pacific")
        refresh_snapshot, refresh_asof, refresh_evidence, refresh_inputs, refresh_pointer_hash = _review_refresh_basis(
            root, refresh_plan, source, source_receipt_hash, action_date, observed)
        exception_evidence = None
    if observed >= deadline_at:
        raise ValueError("Trade planning publication deadline has passed")
    symbols = tuple(config["symbols"])
    forecasts = _validated_independent_forecasts(pd.read_parquet(source / "forecasts.parquet"), action_date=action_date, symbols=symbols,
        late_publication_at=late_publication_time(config, publication.receipt))
    intents = pd.read_parquet(source / "option-strategy-intents.parquet")
    if (len(intents) != len(forecasts) or not intents.groupby("symbol").size().eq(24).all()
            or set(intents.id) != set(forecasts.id + ":OPTION")
            or not intents.plan_status.eq("NO_TRADE_STOCK_ONLY").all()
            or not intents.legs_json.isna().all() or not intents.candidate_key.isna().all()
            or not intents.strategy_source_run.isna().all()):
        raise ValueError("Trade planning requires matching non-executable stock-only option placeholders")
    promoted = verified_promoted_model_groups(publication)
    if any(row.model_group not in promoted for row in forecasts.loc[forecasts.model_status.eq("PROMOTED")].itertuples()):
        raise ValueError("A forecast claims promotion without verified model authority")
    if research_producer_only:
        return _publish_producer_prices(root, publication, forecasts, intents, binding=None, observed=observed,
            deadline_at=deadline_at, price_loader=price_loader, clock=clock,
            fallback_metadata=fallback_metadata, probability_metadata=probability_metadata,
            research_producer_only=True, original_deadline=original_deadline, late_action_date=late_action_date)
    if binding is not None:
        if set(symbols) != set(binding.participants[binding.machine_id]):
            raise ValueError("Producer source universe differs from its account binding")
        return _publish_producer_prices(root, publication, forecasts, intents, binding=binding, observed=observed,
            deadline_at=deadline_at, price_loader=price_loader, clock=clock,
            fallback_metadata=fallback_metadata, probability_metadata=probability_metadata,
            original_deadline=original_deadline, late_action_date=late_action_date)
    run = create_timestamp_directory(root / "ml/gameplan-trade-plan-runs", timestamp=observed)
    report = {"schema_version": VERSION, "observed_at": observed.isoformat(), "action_date": action_date,
              **probability_metadata, **fallback_metadata,
              "source_gameplan_run": source.relative_to(root).as_posix(), "source_receipt_sha256": source_receipt_hash,
              "deadline_at": original_deadline.isoformat(), "effective_deadline_at":deadline_at.isoformat(),
              "deadline_exception":exception_evidence, "execution_authority": AUTHORITY,
              "orders_placed": 0, "broker_orders_enabled": False, "status": "RUNNING"}
    if late_action_date is not None:
        report.update(publication_mode="LATE_RECOVERY", late_action_date=late_action_date)
    if refresh_evidence is not None:
        report.update(publication_mode="INFORMATIONAL_REFRESH", review_refresh=refresh_evidence)
    prior_action_date = previous_action_date(action_date)
    report["previous_session_results_date"] = prior_action_date
    report["previous_session_results_path"] = (root / "ml/gameplan-actuals-review-by-date" /
                                                prior_action_date / "Gameplan-results.md").as_posix()
    _write_json(run / "report.json", report)
    phase = "ACCOUNT_SNAPSHOT"
    try:
        snapshot = refresh_snapshot if refresh_snapshot is not None else (snapshot_loader or capture_trade_planning_snapshot)(root, symbols=symbols)
        _write_json(run / "account-snapshot.json", snapshot)
        planning_snapshot, planning_override = _planning_snapshot(snapshot)
        if (snapshot.get("status") != "OBSERVED" or snapshot.get("cash_status") != "CASH_ONLY_BOUNDED"
                or snapshot.get("available_cash") is None):
            raise ValueError("ACCOUNT_SNAPSHOT_UNAVAILABLE")
        if snapshot.get("ownership", {}).get("safe_for_planning") is not True:
            raise ValueError("OWNERSHIP_SNAPSHOT_UNAVAILABLE")
        phase = "VERIFIED_PRICE_HISTORY"
        prices, price_files, price_report = (price_loader or load_stock_target_prices)(
            root, symbols=symbols, source_contract=config["target_price_source_contract"])
        phase = "PRICE_BANDS_AND_BUDGETS"
        band_asof = refresh_asof if refresh_asof is not None else utc(clock())
        bands = build_entry_price_bands(prices, forecasts, observed_at=band_asof,
                                        lookback_sessions=PLANNING_PRICE_LOOKBACK_SESSIONS,
                                        allow_reference_forward_fill=True, allow_sparse_session_references=True)
        price_path = build_planning_price_path(prices, forecasts, observed_at=band_asof, entry_bands=bands,
                                                allow_reference_forward_fill=True, allow_sparse_session_references=True)
        completion = bands["reference_completion"]
        _write_json(run / "planning-reference-completion.json", completion)
        synthetic = pd.DataFrame(completion["synthetic_bars"])
        if synthetic.empty:
            synthetic = pd.DataFrame(columns=["symbol", "timestamp", "open", "high", "low", "close",
                                              "volume", "is_synthetic", "reason", "original_observed_at"])
        synthetic.to_parquet(run / "synthetic-reference-bars.parquet", index=False)
        policy = StockTraderPolicy()
        rows = _plan_working_price_rows(forecasts, planning_snapshot, bands, price_path, policy=policy)
        phase = "DIRECTION_BASED_CASH_AND_SHARE_PROJECTION"
        try:
            rows, direction_projection = project_direction_trades(rows, planning_snapshot, price_path, policy=policy,
                signal_driven=True, cross_horizon_fallback_policy=fallback_policy)
        except UnavailablePlanningPricePath as unavailable:
            # Complete the informational report without manufacturing prices,
            # fills, ending cash or ending holdings. Other validation errors
            # continue to fail the publication.
            direction_projection = {
                **fallback_metadata,
                "holding_policy": "accumulate_bullish_sell_on_bearish_no_scheduled_expiry_v1",
                "status":"UNAVAILABLE_PRICE_REFERENCES", "unavailable_points":unavailable.points,
                "events":[], "hourly":[], "ending_positions":{}, "summary":{},
                "orders_placed":0, "broker_orders_enabled":False,
                "reason":"Required observed price references or historical pairs are missing; no shared cash projection was calculated.",
            }
        rows.to_parquet(run / "trade-plan.parquet", index=False)
        _write_json(run / "price-bands.json", bands)
        _write_json(run / "planning-price-path.json", price_path)
        _write_json(run / "direction-ledger.json", direction_projection)
        model_reports = json.loads((source / "model-reports.json").read_text(encoding="utf-8"))
        report.update(status="COMPLETE", completed_at=utc(clock()).isoformat(), forecast_rows=len(rows),
                      rows_by_symbol=rows.groupby("symbol").size().to_dict(), option_intent_rows=len(intents),
                      provisional_buy_rows=int(rows.trade_quantity.gt(0).sum()),
                      planned_notional=float(rows.trade_notional_reserved.sum()),
                      quantity_sum=int(rows.trade_quantity.sum()),
                      projected_quantity_rows=int(rows.projected_trade_quantity.gt(0).sum()),
                      projected_quantity_semantics="Per-opportunity affordable horizon allocation; alternatives are not added as simultaneous orders",
                      direction_policy_version=STOCK_DIRECTION_POLICY_VERSION,
                      direction_up_threshold=BULLISH_PROBABILITY, direction_down_threshold=BEARISH_PROBABILITY,
                      price_band_status_counts=rows.price_band_status.value_counts().to_dict(),
                      trade_reason_counts=rows.trade_planning_reason.value_counts().to_dict(),
                      snapshot=snapshot, planning_override=planning_override, sizing_policy=asdict(policy),
                      direction_based_projection=direction_projection,
                      holding_policy=direction_projection["holding_policy"],
                      direction_projection_status=direction_projection.get("status", "AVAILABLE"),
                      opra_history=config.get("opra_history", {}),
                      price_band_policy={k: v for k, v in bands.items() if k not in {"rows", "statistics", "reference_completion"}},
                      planning_price_path={k: v for k, v in price_path.items() if k not in {"points", "reference_completion"}},
                      reference_completion={k: v for k, v in completion.items() if k != "synthetic_bars"},
                      target_price_source_contract=config["target_price_source_contract"],
                      source_price_inventory=price_report,
                      limitations=["Review projections only; the existing live worker revalidates all controls and capital.",
                                   "Price and cash ranges are estimates only. Live orders use the current tradable quote, actual available cash and holdings even when those values are outside the estimates.",
                                   "Planning closing marks may carry the same session's last actual close through up to four after-hours hours in a verified source window. Historical planning pairs disclose these closing carries too; entry prices stay observed. Zero volume is an assumption, not an exchange observation.",
                                   "The direction-based cash/share projection depends on its projected purchase and bearish-sale fills; projected proceeds are not actual spendable broker cash.",
                                   "The separate scheduled-entry preview uses current cash only and requires prior exit confirmation for later entries in a planned horizon."])
        # Optional research assessments add context, never alter the pinned
        # forecast or supply authority for a proposed quantity.
        for pointer, folder, report_name, field in (
            ("ml/gameplan-evaluation-latest/run.json", "ml/gameplan-evaluation-runs", "summary.json", "evaluation_summary"),
            ("ml/stock-trader-model-latest/run.json", "ml/stock-trader-model-runs", "training-report.json", "enrichment_summary"),
        ):
            path = root / pointer
            if path.is_file():
                try:
                    payload = json.loads(path.read_text(encoding="utf-8"))
                    ref = payload.get("current", payload)
                    related = (root / str(ref.get("run_path", ref.get("path", "")))).resolve()
                    if related.parent == (root / folder).resolve():
                        verify_manifest(related)
                        detail = json.loads((related / report_name).read_text(encoding="utf-8"))
                        if field != "enrichment_summary" or detail.get("source_gameplan_run") == source.relative_to(root).as_posix():
                            report[field] = detail
                except (OSError, ValueError, KeyError, RuntimeError):
                    report[field + "_status"] = "UNAVAILABLE_OPTIONAL_CONTEXT"
        phase = "REVIEW_AND_PUBLICATION"
        _write_json(run / "report.json", report)
        (run / "Gameplan.md").write_text(render_trade_review(rows, report, model_reports, source_gameplan=source.as_posix()), encoding="utf-8")
        if utc(clock()) >= deadline_at:
            raise ValueError("TRADE_PLANNING_DEADLINE_PASSED")
        if file_checksum(source / "receipt.json") != source_receipt_hash:
            raise ValueError("PINNED_GAMEPLAN_RECEIPT_CHANGED")
        outputs = ["trade-plan.parquet", "account-snapshot.json", "price-bands.json", "planning-price-path.json",
                   "planning-reference-completion.json", "synthetic-reference-bars.parquet",
                   "direction-ledger.json", "report.json", "Gameplan.md"]
        write_manifest(run, run_timestamp=observed,
                       input_files=[source / "receipt.json", source / "manifest.json", source / "forecasts.parquet", *price_files, *refresh_inputs],
                       output_files=outputs, configuration={"schema_version": VERSION, "action_date": action_date,
                       **probability_metadata, **fallback_metadata,
                       "source_gameplan_run": report["source_gameplan_run"], "source_receipt_sha256": source_receipt_hash,
                       "reference_completion_contract": completion["contract_version"],
                       "allow_reference_forward_fill": True,
                       "allow_sparse_session_references": True,
                       "publication_mode": report.get("publication_mode", "NIGHTLY_REVIEW"),
                       "holding_policy": direction_projection["holding_policy"],
                       "review_refresh": refresh_evidence,
                       "execution_authority": AUTHORITY, "broker_orders_enabled": False, "orders_placed": 0}, datastore_root=root)
        verify_manifest(run)
        if utc(clock()) >= deadline_at:
            raise ValueError("TRADE_PLANNING_DEADLINE_PASSED")
        terminal = {"schema_version": VERSION, "status": "COMPLETE", "run_path": run.relative_to(root).as_posix(),
                    **probability_metadata, **fallback_metadata,
                    "action_date": action_date, "source_gameplan_run": report["source_gameplan_run"],
                    "source_receipt_sha256": source_receipt_hash, "manifest_sha256": file_checksum(run / "manifest.json"),
                    "forecast_rows": len(rows), "orders_placed": 0, "broker_orders_enabled": False,
                    "holding_policy": direction_projection["holding_policy"],
                    "execution_authority": AUTHORITY, "completed_at": utc(clock()).isoformat()}
        _write_json(run / "receipt.json", terminal)
        if utc(clock()) >= deadline_at:
            raise ValueError("TRADE_PLANNING_DEADLINE_PASSED")
        if refresh_pointer_hash is not None and file_checksum(root / "ml/gameplan-trade-plan-latest/run.json") != refresh_pointer_hash:
            raise ValueError("REFRESH_PLAN_CHANGED")
        _write_json(root / "ml/gameplan-trade-plan-latest/run.json", {"schema_version": VERSION, "current": {
            "run_path": terminal["run_path"], "action_date": action_date,
            "source_receipt_sha256": source_receipt_hash, "receipt_sha256": file_checksum(run / "receipt.json")}})
        return run
    except Exception as exc:
        # Do not serialize broker exception text, credentials or identifiers.
        safe_codes = {"ACCOUNT_SNAPSHOT_UNAVAILABLE", "OWNERSHIP_SNAPSHOT_UNAVAILABLE",
                      "TRADE_PLANNING_DEADLINE_PASSED", "PINNED_GAMEPLAN_RECEIPT_CHANGED", "REFRESH_PLAN_CHANGED"}
        code = str(exc) if str(exc) in safe_codes else "TRADE_PLANNING_VALIDATION_FAILED"
        report.update(status="FAILED", failure_type=type(exc).__name__, failure_phase=phase,
                      failure_code=code, completed_at=utc(clock()).isoformat())
        _write_json(run / "report.json", report)
        _write_json(run / "receipt.json", {"schema_version": VERSION, "status": "FAILED", "failure_type": type(exc).__name__,
                    "failure_code": code, "failure_phase": phase,
                    "report_sha256": file_checksum(run / "report.json"), "orders_placed": 0, "broker_orders_enabled": False})
        raise RuntimeError(f"Trade planning failed ({type(exc).__name__}); review {run / 'report.json'}") from None


def main(argv: list[str] | None = None) -> int:
    from datafetching.parquet_store import DATASTORE_TARGETS, resolve_datastore_dir
    from datafetching.runtime_lock import exclusive_runtime_lock
    parser = argparse.ArgumentParser(description=__doc__)
    datastore = parser.add_mutually_exclusive_group()
    datastore.add_argument("--datastore", type=Path)
    datastore.add_argument("--datastore-target", choices=tuple(DATASTORE_TARGETS), default="pc")
    parser.add_argument("--gameplan-run", required=True, type=Path)
    parser.add_argument("--deadline")
    parser.add_argument("--late-action-date", help="Explicit date-pinned late recovery using its frozen deadline")
    parser.add_argument('--deadline-exception', type=Path)
    parser.add_argument('--refresh-plan', type=Path,
                        help="Recalculate the current informational review using its original snapshot and planning cutoff")
    parser.add_argument("--account-producer-only", action="store_true")
    parser.add_argument("--research-producer-only", action="store_true")
    parser.add_argument("--expected-account-config")
    args = parser.parse_args(argv)
    root = resolve_datastore_dir(root_dir=args.datastore, target=None if args.datastore else args.datastore_target)
    with exclusive_runtime_lock(root / "state/gameplan-trade-planning.lock", process_name="gameplan trade planning"):
        extra = {'deadline_exception':args.deadline_exception} if args.deadline_exception is not None else {}
        if args.late_action_date is not None:
            extra['late_action_date'] = args.late_action_date
        if args.refresh_plan is not None:
            extra['refresh_plan'] = args.refresh_plan
        if args.account_producer_only or args.expected_account_config is not None:
            extra.update(account_producer_only=args.account_producer_only, expected_account_config=args.expected_account_config)
        if args.research_producer_only:
            extra["research_producer_only"] = True
        run = publish_trade_plan(root, gameplan_run=args.gameplan_run, deadline=args.deadline, **extra)
    print(json.dumps({"status": "COMPLETE", "run_path": str(run), "review_path": str(run / "Gameplan.md"), "orders_placed": 0}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
