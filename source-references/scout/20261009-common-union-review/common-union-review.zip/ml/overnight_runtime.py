from __future__ import annotations

import argparse
import json
import os
import re
import signal
import subprocess
import sys
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Mapping, Sequence
from zoneinfo import ZoneInfo

import exchange_calendars as xcals
import pandas as pd

from datafetching.parquet_store import DATASTORE_TARGETS, resolve_datastore_dir
from datafetching.runtime_lock import exclusive_runtime_lock
from datafetching.symbol_universe import configured_watchlist_path
from ml.artifacts import create_timestamp_directory, file_checksum, utc_timestamp


OVERNIGHT_RUNTIME_VERSION = "supervised-overnight-gameplan-runtime-v2"
OVERNIGHT_NOOP_VERSION = "single-owner-overnight-gameplan-noop-v1"
SCHEDULE_TIMEZONE = ZoneInfo("America/Los_Angeles")
ACTION_DAY_CLOSE_HOUR = 17
STAGE_ORDER = (
    "loop_a_close_fetch",
    "loop_b_directional_generation",
    "gameplan_evaluation",
    "strategy_profit_training",
    "strategy_generation",
    "gameplan_publication",
)
INDEPENDENT_ENRICHMENT_STAGE = "stock_enrichment_training"
INDEPENDENT_TRADE_PLANNING_STAGE = "gameplan_trade_planning"
INDEPENDENT_ACTUALS_REVIEW_STAGE = "gameplan_actuals_review"
ACCOUNT_GAMEPLAN_STAGE = "account_gameplan_preparation"
ACCOUNT_REVIEW_STAGE = "account_actuals_summary"
ACCOUNT_TAIL_STAGES = (ACCOUNT_GAMEPLAN_STAGE, ACCOUNT_REVIEW_STAGE)
INDEPENDENT_HISTORY_STAGE = "stock_target_history"
INDEPENDENT_TAIL_STAGES = (INDEPENDENT_ENRICHMENT_STAGE, INDEPENDENT_TRADE_PLANNING_STAGE, INDEPENDENT_ACTUALS_REVIEW_STAGE)
LEGACY_STAGE_ORDER = (*STAGE_ORDER[:2], INDEPENDENT_HISTORY_STAGE, *STAGE_ORDER[2:],
                   INDEPENDENT_ENRICHMENT_STAGE, INDEPENDENT_TRADE_PLANNING_STAGE,
                   ACCOUNT_GAMEPLAN_STAGE, INDEPENDENT_ACTUALS_REVIEW_STAGE, ACCOUNT_REVIEW_STAGE)
GAMEPLAN_STATS_STAGE = "gameplan_stats"
# The coordinator completes and reviews model feedback between gameplan_stats
# and loop_b_directional_generation. Completed segments are not failed resumes.
STATS_FIRST_STAGE_ORDER = (STAGE_ORDER[0], INDEPENDENT_HISTORY_STAGE, GAMEPLAN_STATS_STAGE,
                           *STAGE_ORDER[1:], INDEPENDENT_ENRICHMENT_STAGE, INDEPENDENT_TRADE_PLANNING_STAGE)
ALL_STAGE_ORDER = (*LEGACY_STAGE_ORDER, GAMEPLAN_STATS_STAGE)
STOCK_PRICE_SOURCES = ("canonical-equity-minute-v1", "xnas-itch-archive-v1")


@dataclass(frozen=True)
class StageResult:
    stage: str
    command: tuple[str, ...]
    started_at: str
    finished_at: str
    elapsed_seconds: float
    exit_code: int | None
    status: str
    log_path: str
    error: str | None = None


def scheduled_session_eligibility(
    observed_at: object | None = None,
) -> dict[str, object]:
    """Return whether a scheduled wake follows an eligible XNYS action day.

    The recurrence is weekday-based, so this calendar check is what prevents a
    US market holiday from retraining on unchanged data or replacing the next
    session's existing frozen plan.  The system's action day ends at 17:00 PT,
    later than the regular XNYS close used by the exchange calendar.
    """

    observed = utc_timestamp(observed_at)
    local = observed.tz_convert(SCHEDULE_TIMEZONE)
    label = pd.Timestamp(local.date())
    calendar = xcals.get_calendar(
        "XNYS",
        start=label - pd.Timedelta(days=10),
        end=label + pd.Timedelta(days=14),
    )
    is_session = bool(calendar.is_session(label))
    next_session = calendar.date_to_session(label, direction="next")
    base = {
        "observed_at": observed.isoformat(),
        "observed_at_local": local.isoformat(),
        "local_date": local.date().isoformat(),
        "calendar": "XNYS",
        "is_exchange_session": is_session,
        "next_exchange_session": pd.Timestamp(next_session).date().isoformat(),
    }
    if not is_session:
        return {
            **base,
            "eligible": False,
            "status": "NOOP_NON_SESSION_DATE",
            "reason": "The scheduled local date is not an XNYS session.",
        }
    if local.hour < ACTION_DAY_CLOSE_HOUR:
        return {
            **base,
            "eligible": False,
            "status": "FAIL_ACTION_DAY_NOT_CLOSED",
            "reason": "The 04:00-17:00 PT action day has not finished.",
        }
    return {
        **base,
        "eligible": True,
        "status": "ELIGIBLE_COMPLETED_ACTION_SESSION",
        "reason": "The scheduled wake follows a completed XNYS action date.",
    }


def record_scheduled_noop(
    datastore_root: Path,
    *,
    eligibility: Mapping[str, object],
) -> Path:
    """Publish a receipt for an expected non-session scheduled wake."""

    if eligibility.get("status") != "NOOP_NON_SESSION_DATE":
        raise ValueError("Only a non-session date may be recorded as a no-op")
    root = Path(datastore_root).resolve()
    observed = utc_timestamp(eligibility.get("observed_at"))
    run = create_timestamp_directory(
        root / "ml" / "overnight-runs",
        timestamp=observed,
    )
    report_path = run / "stage-report.json"
    report = {
        "schema_version": OVERNIGHT_NOOP_VERSION,
        "run_timestamp": observed.isoformat(),
        "datastore_root": str(root),
        "status": "NOOP_NON_SESSION_DATE",
        "eligibility": dict(eligibility),
        "stages": [],
        "prior_gameplan_pointer_preserved": True,
        "broker_orders_enabled": False,
        "orders_placed": 0,
    }
    _write_json_atomic(report_path, report)
    _write_json_atomic(
        run / "receipt.json",
        {
            "schema_version": OVERNIGHT_NOOP_VERSION,
            "run_path": run.relative_to(root).as_posix(),
            "status": "NOOP_NON_SESSION_DATE",
            "completed_at": utc_timestamp().isoformat(),
            "stage_report_size": report_path.stat().st_size,
            "stage_report_checksum_sha256": file_checksum(report_path),
            "prior_gameplan_pointer_preserved": True,
            "broker_orders_enabled": False,
            "orders_placed": 0,
        },
    )
    return run


def _production_watchlist(repository_root: Path) -> Path:
    return configured_watchlist_path(repository_root)


def _pin_stock_gameplan(root: Path, *, stock_price_source: str, deadline_at: pd.Timestamp,
                        pinned: Mapping[str, object] | None = None,
                        probability_target: str | None = None,
                        archive_history: bool = False) -> dict[str, str]:
    """Keep post-publication stages on one immutable successor across resume."""
    from ml.nightly_gameplan import read_current_gameplan, read_gameplan_run

    root = Path(root).resolve()
    if pinned is None:
        publication = read_current_gameplan(root)
    else:
        path = (root / str(pinned.get("run_path", ""))).resolve()
        if not path.is_relative_to(root / "ml/nightly-gameplan-runs"):
            raise ValueError("Pinned stock training publication escapes its run directory")
        publication = read_gameplan_run(root, path)
        if file_checksum(path / "receipt.json") != pinned.get("receipt_sha256"):
            raise ValueError("Pinned stock training publication receipt changed")
    config = publication.manifest.get("configuration", {})
    from ml.gameplan_source_selection import ARCHIVE_SOURCE_SELECTION_VERSION
    if ((config.get("archive_history") is True) != archive_history
            or (config.get("source_selection_contract") == ARCHIVE_SOURCE_SELECTION_VERSION) != archive_history):
        raise ValueError("Pinned stock publication differs from the saved archive history policy")
    if probability_target is not None:
        from ml.gameplan_probability_target import probability_target_contract
        if probability_target_contract(config) != probability_target:
            raise ValueError("Pinned stock publication differs from the saved probability target")
    action_date = deadline_at.tz_convert(SCHEDULE_TIMEZONE).date().isoformat()
    if (config.get("target_contract_version") != "independent-stock-targets-v1"
            or config.get("target_price_source_contract", STOCK_PRICE_SOURCES[0]) != stock_price_source
            or config.get("action_date") != action_date
            or publication.receipt.get("action_date") != action_date):
        raise ValueError("Stock training publication differs from its source or original action deadline")
    return {"run_path": publication.run_directory.relative_to(root).as_posix(),
            "receipt_sha256": file_checksum(publication.run_directory / "receipt.json"),
            "action_date": action_date}


def _pin_account_trade_plan(root, *, gameplan, pinned=None):
    from ml.artifacts import verify_manifest
    if pinned is None:
        pointer = json.loads((root / "ml/gameplan-trade-plan-latest/run.json").read_text())
        pinned = pointer["current"]
    path = (root / pinned["run_path"]).resolve()
    if path.parent != (root / "ml/gameplan-trade-plan-runs").resolve():
        raise ValueError("Account planning trade reference escapes its native run root")
    receipt = json.loads((path / "receipt.json").read_text())
    checksum = file_checksum(path / "receipt.json")
    if (pinned.get("receipt_sha256") != checksum or receipt.get("status") != "COMPLETE"
            or receipt.get("source_gameplan_run") != gameplan["run_path"]
            or receipt.get("source_receipt_sha256") != gameplan["receipt_sha256"]
            or receipt.get("manifest_sha256") != file_checksum(path / "manifest.json")
            or receipt.get("orders_placed") != 0 or receipt.get("broker_orders_enabled") is not False):
        raise ValueError("Account planning requires the exact completed native trade plan")
    verify_manifest(path)
    return {"run_path": pinned["run_path"], "receipt_sha256": checksum}


def run_overnight_pipeline(
    datastore_root: Path,
    *,
    datastore_argument: tuple[str, str],
    repository_root: Path,
    start_at: str = STAGE_ORDER[0],
    stop_after: str | None = None,
    reporter=print,
    resume_run: Path | None = None,
    deadline: object | None = None,
    poll_seconds: float = 30.0,
    stock_only: bool = False,
    independent_stock_horizons: bool = False,
    stock_price_source: str | None = None,
    probability_target_contract: str | None = None,
    archive_history: bool | None = None,
    deadline_exception: Path | None = None,
    stats_first: bool | None = None,
    review_action_date: str | None = None,
    model_feedback: Path | None = None,
    late_action_date: str | None = None,
    workflow_recovery: Path | None = None,
    recovery_spec: Path | None = None,
    research_producer_only: bool = False,
    pinned_gameplan: Mapping[str, str] | None = None,
) -> Path:
    """Run the one-owner post-close chain and fail before downstream stages."""

    root = Path(datastore_root).resolve()
    repository = Path(repository_root).resolve()
    created = utc_timestamp()
    from ml.gameplan_probability_target import RAW_DIRECTION_TARGET, LEGACY_COST_TARGET, resolve_probability_target
    if deadline_exception is not None and resume_run is None:
        raise ValueError('A deadline exception requires an existing pinned tail attempt')
    if recovery_spec is not None and any(value is not None for value in (workflow_recovery, deadline_exception, late_action_date)):
        raise ValueError("Use one frozen native recovery route")
    recovery_record = recovery_evidence = None
    if workflow_recovery is not None:
        from ml.nightly_dispatch import validate_recovery
        recovery_record, recovery_evidence = validate_recovery(workflow_recovery, root=root, now=created)
        if deadline_exception is not None:
            raise ValueError("Use one frozen native continuation route")
    resume = _resume_configuration(root, resume_run, deadline_exception=deadline_exception,
                                   workflow_recovery=workflow_recovery, recovery_spec=recovery_spec) if resume_run else None
    if resume:
        if research_producer_only and resume.get("research_producer_only") is not True:
            raise ValueError("Resume must preserve its account or research publication role")
        research_producer_only = resume.get("research_producer_only") is True
        if pinned_gameplan is not None and pinned_gameplan != resume.get("enrichment_gameplan"):
            raise ValueError("Resume must preserve the original prediction publication")
        previous_late_date = recovery_record["action_date"] if recovery_record else resume.get("late_action_date")
        if late_action_date is not None and late_action_date != previous_late_date:
            raise ValueError("Resume must preserve its late-publication action date")
        late_action_date = previous_late_date
        start_at, stop_after = resume["failed_stage"], resume["stage_order"][-1]
        stock_only = stock_only or resume.get("stock_only") is True
        independent_stock_horizons = independent_stock_horizons or resume.get("independent_stock_horizons") is True
        previous_source = resume.get("stock_price_source", STOCK_PRICE_SOURCES[0])
        if stock_price_source is not None and stock_price_source != previous_source:
            raise ValueError("Resume must preserve its verified stock price source; use a separate experiment run")
        stock_price_source = previous_source
        previous_target = resolve_probability_target(resume.get("probability_target_contract"))
        if probability_target_contract is not None and probability_target_contract != previous_target:
            raise ValueError("Resume must preserve its verified probability target contract")
        probability_target_contract = previous_target
        previous_archive_history = resume.get("archive_history") is True
        if archive_history is not None and archive_history != previous_archive_history:
            raise ValueError("Resume must preserve its verified archive history policy")
        archive_history = previous_archive_history
        previous_stats_first = resume.get("stats_first") is True
        if stats_first is not None and stats_first != previous_stats_first:
            raise ValueError("Resume must preserve its verified Stats ordering")
        stats_first = previous_stats_first
        previous_review_date = resume.get("review_action_date")
        if review_action_date is not None and review_action_date != previous_review_date:
            raise ValueError("Resume must preserve its reviewed action date")
        review_action_date = previous_review_date
        previous_feedback = resume.get("model_feedback")
        if model_feedback is not None and (not previous_feedback or str(Path(model_feedback).resolve()) != previous_feedback["path"]):
            raise ValueError("Resume must preserve its reviewed model feedback")
        model_feedback = Path(previous_feedback["path"]) if previous_feedback else None
        if previous_feedback and file_checksum(model_feedback) != previous_feedback["sha256"]:
            raise ValueError("Reviewed model feedback changed since the failed attempt")
    stats_first = stats_first is True
    from ml.account_gameplan.config import load_account_config
    # Stats-first prepares each owner's local plan. An installed legacy account
    # binding must not silently append synthesis or replace it with a prices-only
    # producer publication. Historical retries retain exactly their saved tail.
    account_config = None if stats_first or research_producer_only else load_account_config(root)
    account_stage_requested = (any(stage in resume["stage_order"] for stage in ACCOUNT_TAIL_STAGES) if resume
                               else account_config is not None and independent_stock_horizons)
    if account_stage_requested:
        if account_config is None:
            raise ValueError("Saved combined-account preparation requires its original configuration")
        if resume and resume.get("account_config_sha256") != account_config.fingerprint:
            raise ValueError("Resume must preserve its saved combined-account host and universe binding")
    archive_history = archive_history is True
    stock_price_source = stock_price_source or STOCK_PRICE_SOURCES[0]
    if stock_price_source not in STOCK_PRICE_SOURCES:
        raise ValueError("Unknown stock price source contract")
    if archive_history and (not independent_stock_horizons or stock_price_source != "xnas-itch-archive-v1"):
        raise ValueError("Archive history requires independent XNAS stock preparation")
    if independent_stock_horizons and not stock_only:
        raise ValueError("Independent stock horizons require explicit stock-only preparation")
    if stats_first and not independent_stock_horizons:
        raise ValueError("Stats-first preparation requires independent stock horizons")
    if research_producer_only and (not stats_first or not stock_only or not independent_stock_horizons):
        raise ValueError("Research-only publication requires Stats-first independent stock preparation")
    if review_action_date is not None and not stats_first:
        raise ValueError("A reviewed action date requires Stats-first preparation")
    probability_target_contract = resolve_probability_target(
        probability_target_contract or (RAW_DIRECTION_TARGET if independent_stock_horizons else LEGACY_COST_TARGET))
    if not independent_stock_horizons and probability_target_contract != LEGACY_COST_TARGET:
        raise ValueError("Raw direction preparation requires independent stock horizons")
    if stock_price_source != STOCK_PRICE_SOURCES[0] and not independent_stock_horizons:
        raise ValueError("Alternate stock price sources require independent stock horizons")
    if stop_after is None:
        stop_after = (INDEPENDENT_TRADE_PLANNING_STAGE if stats_first else
                      ACCOUNT_REVIEW_STAGE if account_stage_requested else
                      INDEPENDENT_ACTUALS_REVIEW_STAGE if independent_stock_horizons else STAGE_ORDER[-1])
    stage_order = STATS_FIRST_STAGE_ORDER if stats_first else LEGACY_STAGE_ORDER
    if start_at not in stage_order or stop_after not in stage_order:
        raise ValueError("Unknown overnight stage boundary")
    start_index, stop_index = stage_order.index(start_at), stage_order.index(stop_after)
    if start_index > stop_index:
        raise ValueError("start_at must not come after stop_after")
    if stop_after in (*INDEPENDENT_TAIL_STAGES, *ACCOUNT_TAIL_STAGES) and not independent_stock_horizons:
        raise ValueError("Independent post-publication stages require independent stock horizons")
    deadline_at = utc_timestamp(resume["deadline_at"] if resume else deadline) if (resume or deadline is not None) else next_action_deadline(created)
    effective_deadline = utc_timestamp(resume.get('effective_deadline_at', resume['deadline_at'])) if resume else deadline_at
    recovery = None
    if recovery_spec is not None:
        from ml.nightly_recovery import verify_recovery
        recovery = verify_recovery(root, recovery_spec, created,
                                   action_date=deadline_at.tz_convert(SCHEDULE_TIMEZONE).date().isoformat())
        if (not stats_first or not stock_only or not independent_stock_horizons
                or review_action_date != recovery['authorization']['source_session']
                or deadline_at != utc_timestamp(recovery['authorization']['original_deadline_at'])):
            raise ValueError('Late recovery must preserve the Stats-first session and original deadline')
        effective_deadline = utc_timestamp(recovery['authorization']['expires_at'])
    if recovery_record:
        if (not stats_first or not stock_only or review_action_date != recovery_record["source_session"]
                or deadline_at != utc_timestamp(recovery_record["original_deadline_at"])):
            raise ValueError("Scheduled recovery must retain the original stock preparation session")
        effective_deadline = utc_timestamp(recovery_record["expires_at"])
        late_action_date = recovery_record["action_date"]
    selected = stage_order[start_index : stop_index + 1]
    if resume:
        # A new optional stage must never extend an older saved attempt.
        selected = tuple(stage for stage in selected if stage in resume["stage_order"])
    elif not account_stage_requested:
        selected = tuple(stage for stage in selected if stage not in ACCOUNT_TAIL_STAGES)
    if start_at in ACCOUNT_TAIL_STAGES and not account_stage_requested:
        raise ValueError("Combined-account preparation is not configured")
    if stock_price_source != "xnas-itch-archive-v1":
        selected = tuple(stage for stage in selected if stage != INDEPENDENT_HISTORY_STAGE)
    omitted_option_stages: list[str] = []
    if stock_only:
        option_stages = ("strategy_profit_training", "strategy_generation")
        previous_omissions = resume.get("omitted_option_stages", []) if resume else []
        omitted_option_stages = [
            stage for stage in option_stages
            if stage in selected or stage in previous_omissions
        ]
        selected = tuple(stage for stage in selected if stage not in option_stages)
    if not selected:
        raise ValueError("No overnight stages remain within the requested stock-only boundaries")
    feedback_binding = None
    if model_feedback is not None:
        model_feedback = Path(model_feedback).resolve()
        feedback_binding = {"path": str(model_feedback), "sha256": file_checksum(model_feedback)}
    if stats_first:
        from ml.gameplan_actuals_review import completed_session_context
        review_action_date = completed_session_context(created, review_action_date)["action_date"]
        if GAMEPLAN_STATS_STAGE in selected and any(stage in selected for stage in ("loop_b_directional_generation", "gameplan_publication")):
            raise ValueError("Stop after gameplan_stats for model review before starting the training segment")
        if any(stage in selected for stage in ("loop_b_directional_generation", "gameplan_publication")) and model_feedback is None:
            raise ValueError("Stats-first training requires reviewed model feedback; complete the gameplan_stats boundary first")
    run = create_timestamp_directory(
        root / "ml" / "overnight-runs",
        timestamp=created,
    )
    python = str(Path(sys.executable).resolve())
    commands: dict[str, tuple[str, ...]] = {
        "loop_a_close_fetch": (
            python,
            "-u",
            "-m",
            "datafetching.orchestrate",
            *datastore_argument,
            "--watchlist",
            str(_production_watchlist(repository)),
            "--providers",
            "databento",
            "fmp",
            "fred",
            "schwab",
            "sec",
            "--cme-mode",
            "inline",
            "--options-mode",
            "inline",
            "--opra-history-mode",
            "daily",
            "--opra-history-utc-hour",
            "0",
            "--opra-history-max-estimated-download-bytes",
            "20000000000",
            "--opra-history-max-estimated-cost-usd",
            "1",
            "--opra-history-max-catchup-days",
            "30",
            "--bar-readiness-recovery-timeout-seconds",
            "420",
            "--bar-readiness-recovery-poll-seconds",
            "10",
            "--once",
        ),
        "loop_b_directional_generation": (
            python,
            "-u",
            "-m",
            "ml.prediction_runtime",
            *datastore_argument,
            "--watchlist",
            str(_production_watchlist(repository)),
            "--provider",
            "databento",
            "--horizons",
            "1h",
            "4h",
            "1d",
            "1w",
            "--feature-profile",
            "loop-a-all-bsgp-active-v3",
            "--model-family",
            "logistic",
            "--calibration",
            "platt",
            "--round-trip-cost",
            "0.001",
            "--require-all-routes",
            "--once",
        ),
        "strategy_profit_training": (
            python,
            "-u",
            "-m",
            "ml.strategy_profit_training_runtime",
            *datastore_argument,
            "--once",
        ),
        "gameplan_evaluation": (
            python, "-u", "-m", "ml.gameplan_evaluation", *datastore_argument,
        ),
        GAMEPLAN_STATS_STAGE: (
            python, "-u", "-m", "ml.gameplan_actuals_review", *datastore_argument,
            "--completed-session", "--action-date", str(review_action_date),
            "--deadline", effective_deadline.isoformat(),
        ),
        "strategy_generation": (
            python,
            "-u",
            "-m",
            "ml.strategy_runtime",
            *datastore_argument,
            "--pricing-mode",
            "active",
            "--once",
        ),
        "gameplan_publication": (
            python,
            "-u",
            "-m",
            "ml.nightly_gameplan",
            *datastore_argument,
            "--once",
            *(("--stock-only",) if stock_only else ()),
            *(("--independent-stock-horizons",) if independent_stock_horizons else ()),
            *(("--stock-price-source", stock_price_source) if independent_stock_horizons else ()),
            *(("--probability-target-contract", probability_target_contract) if independent_stock_horizons else ()),
            *(("--archive-history",) if archive_history else ()),
            *(("--model-feedback", str(model_feedback)) if model_feedback is not None else ()),
            *(("--late-action-date", late_action_date) if late_action_date is not None else ()),
            *(("--recovery-spec", str(recovery_spec)) if recovery_spec is not None else ()),
        ),
        INDEPENDENT_ENRICHMENT_STAGE: (
            python, "-u", "-m", "ml.stock_trader.independent_training", *datastore_argument,
        ),
        INDEPENDENT_TRADE_PLANNING_STAGE: (
            python, "-u", "-m", "ml.gameplan_trade_planning", *datastore_argument,
        ),
        INDEPENDENT_ACTUALS_REVIEW_STAGE: (
            python, "-u", "-m", "ml.gameplan_actuals_review", *datastore_argument,
        ),
        ACCOUNT_GAMEPLAN_STAGE: (
            python, "-u", "-m", "ml.account_gameplan.preparation", *datastore_argument,
        ),
        ACCOUNT_REVIEW_STAGE: (
            python, "-u", "-m", "ml.account_gameplan.review", *datastore_argument,
        ),
        INDEPENDENT_HISTORY_STAGE: (
            python, "-u", "-m", "ml.stock_target_history", *datastore_argument, "--execute",
            *(("--extend-to-feature-history",) if archive_history else ()),
        ),
    }
    report: dict[str, object] = {
        "schema_version": OVERNIGHT_RUNTIME_VERSION,
        "run_timestamp": created.isoformat(), "owner_pid": os.getpid(),
        "owner_created_at": _process_created_at(os.getpid()),
        "repository_root": str(repository), "datastore_root": str(root),
        "deadline_at": deadline_at.isoformat(), "stage_order": list(selected),
        "effective_deadline_at": effective_deadline.isoformat(),
        "deadline_exception": resume.get('deadline_exception') if resume else None,
        "resumed_from": str(Path(resume_run).resolve()) if resume_run else None,
        "completed_stages_from_previous_attempt": resume["completed_stages"] if resume else [],
        "broker_orders_enabled": False, "orders_placed": 0,
        "status": "RUNNING", "stages": [], "current_stage": None,
        "stats_first": stats_first, "review_action_date": review_action_date,
        "model_feedback": feedback_binding,
        "late_action_date": late_action_date,
        "workflow_recovery": recovery_evidence or (resume.get("workflow_recovery") if resume else None),
        "recovery": recovery or (resume.get("recovery") if resume else None),
        "research_producer_only": research_producer_only,
    }
    if pinned_gameplan is not None:
        report["enrichment_gameplan"] = dict(pinned_gameplan)
    if account_stage_requested:
        report["account_config_sha256"] = account_config.fingerprint
        if resume and resume.get("account_trade_plan"):
            report["account_trade_plan"] = resume["account_trade_plan"]
    if stock_only:
        report.update(
            stock_only=True,
            preparation_scope="STOCK_ONLY",
            omitted_option_stages=omitted_option_stages,
        )
    if independent_stock_horizons:
        report.update(independent_stock_horizons=True, target_contract_version="independent-stock-targets-v1",
                      stock_price_source=stock_price_source, probability_target_contract=probability_target_contract,
                      archive_history=archive_history,
                      gameplan_variant="YG" if probability_target_contract == RAW_DIRECTION_TARGET else "OG")
        if resume and resume.get("enrichment_gameplan"):
            report["enrichment_gameplan"] = resume["enrichment_gameplan"]
    report_path = run / "stage-report.json"
    _write_json_atomic(report_path, report)
    _write_json_atomic(root / "ml/overnight-latest/run.json", {"run_path": run.relative_to(root).as_posix()})
    if reporter is not None:
        reporter(f"OVERNIGHT RUN {run}; deadline={deadline_at.isoformat()}")
    results: list[StageResult] = []
    stage = selected[0]
    error: BaseException | None = None
    try:
        for stage in selected:
            command = commands[stage]
            started = utc_timestamp()
            monotonic_started = time.monotonic()
            log_path = run / f"{stage}.log"
            report["current_stage"] = stage
            report["current_log_path"] = str(log_path)
            report["heartbeat_at"] = started.isoformat()
            report["stage_started_at"] = started.isoformat()
            report["stage_health"] = "STARTING"
            report["child_pid"] = None
            _write_json_atomic(report_path, report)
            if reporter is not None:
                reporter(f"OVERNIGHT START {stage} at {started.isoformat()}; log={log_path}")
            exit_code: int | None = None
            stage_error: BaseException | None = None
            status = "COMPLETE"

            def progress(payload: Mapping[str, object]) -> None:
                report.update(payload)
                with (run / "health.jsonl").open("a", encoding="utf-8") as history:
                    history.write(json.dumps({"stage": stage, **payload}, default=str) + "\n")
                _write_json_atomic(report_path, report)
                if reporter is not None:
                    reporter("OVERNIGHT HEALTH " + json.dumps(dict(payload), default=str))

            try:
                if stage in ("loop_b_directional_generation", "gameplan_publication") and feedback_binding:
                    if file_checksum(model_feedback) != feedback_binding["sha256"]:
                        raise ValueError("Reviewed model feedback changed before training")
                if stage in (*INDEPENDENT_TAIL_STAGES, *ACCOUNT_TAIL_STAGES):
                    if resume and start_at in (*INDEPENDENT_TAIL_STAGES, *ACCOUNT_TAIL_STAGES) and not report.get("enrichment_gameplan"):
                        raise ValueError("Failed independent tail stage has no pinned Gameplan; resume cannot select another publication")
                    report["enrichment_gameplan"] = _pin_stock_gameplan(
                        root, stock_price_source=stock_price_source, deadline_at=deadline_at,
                        pinned=report.get("enrichment_gameplan"),
                        probability_target=probability_target_contract,
                        archive_history=archive_history,
                    )
                    command = (*command, "--gameplan-run", str(root / report["enrichment_gameplan"]["run_path"]))
                    if stage in (INDEPENDENT_TRADE_PLANNING_STAGE, INDEPENDENT_ACTUALS_REVIEW_STAGE, *ACCOUNT_TAIL_STAGES):
                        stage_deadline = (utc_timestamp(resume["deadline_exception"]["authorization"]["original_deadline_at"])
                                          if resume and resume.get("deadline_exception") else deadline_at)
                        stage_late_date = late_action_date
                        stage_exception = recovery_spec if recovery_spec is not None else deadline_exception
                        if (resume and resume.get("deadline_exception") and report.get("workflow_recovery")):
                            source = root / report["enrichment_gameplan"]["run_path"]
                            source_config = json.loads((source / "manifest.json").read_text(encoding="utf-8")).get("configuration", {})
                            if source_config.get("publication_mode") != "LATE_RECOVERY":
                                stage_late_date = None
                        if stage == INDEPENDENT_TRADE_PLANNING_STAGE and research_producer_only:
                            command = (*command, "--research-producer-only")
                        if recovery_record and stage == INDEPENDENT_TRADE_PLANNING_STAGE:
                            source = root / report["enrichment_gameplan"]["run_path"]
                            source_config = json.loads((source / "manifest.json").read_text(encoding="utf-8")).get("configuration", {})
                            if source_config.get("publication_mode") == "LATE_RECOVERY":
                                stage_deadline = effective_deadline
                            else:
                                # Predictions frozen before 04:00 stay normal.
                                # Only their unchanged planning tail receives a
                                # scoped exception under the recorded authority.
                                from ml.preparation_deadline import VERSION as EXCEPTION_VERSION
                                stage_late_date = None
                                stage_exception = run / "scheduled-planning-exception.json"
                                _write_json_atomic(stage_exception, {
                                    "schema_version": EXCEPTION_VERSION,
                                    "scope": "PINNED_STOCK_PLANNING_AND_ACTUALS_ONLY",
                                    "operator_authorized": True, "orders_authorized": False,
                                    "authorization_text": recovery_record["authorization"],
                                    "authorization_source": str(Path(workflow_recovery).resolve()),
                                    "gameplan_run": source.relative_to(root).as_posix(),
                                    "gameplan_receipt_sha256": report["enrichment_gameplan"]["receipt_sha256"],
                                    "action_date": recovery_record["action_date"],
                                    "original_deadline_at": deadline_at.isoformat(),
                                    "approved_at": recovery_record["approved_at"],
                                    "expires_at": effective_deadline.isoformat()})
                        command = (*command, "--deadline", stage_deadline.isoformat())
                        if stage == INDEPENDENT_TRADE_PLANNING_STAGE and stage_late_date is not None:
                            command = (*command, "--late-action-date", stage_late_date)
                        if stage_exception is not None:
                            command = (*command, '--deadline-exception', str(Path(stage_exception).resolve()))
                    if stage == ACCOUNT_GAMEPLAN_STAGE:
                        if load_account_config(root).fingerprint != report["account_config_sha256"]:
                            raise ValueError("Account preparation configuration changed during the native run")
                        report["account_trade_plan"] = _pin_account_trade_plan(root,
                            gameplan=report["enrichment_gameplan"], pinned=report.get("account_trade_plan"))
                        command = (*command, "--trade-plan-run", str(root / report["account_trade_plan"]["run_path"]),
                                   "--expected-config", report["account_config_sha256"])
                    if stage == INDEPENDENT_TRADE_PLANNING_STAGE and account_stage_requested:
                        command = (*command, "--account-producer-only", "--expected-account-config", report["account_config_sha256"])
                    if stage == ACCOUNT_REVIEW_STAGE:
                        command = (*command, "--expected-config", report["account_config_sha256"])
                    _write_json_atomic(report_path, report)
                exit_code = _run_stage(command, repository=repository, log_path=log_path,
                    deadline=effective_deadline, stop_request=run / "stop-request.json",
                    progress=progress, poll_seconds=poll_seconds)
                if exit_code:
                    raise RuntimeError(f"{stage} exited with code {exit_code}; inspect {log_path}")
            except BaseException as exc:
                stage_error = exc
                status = "TIMED_OUT" if isinstance(exc, TimeoutError) else "CANCELLED" if isinstance(exc, (InterruptedError, KeyboardInterrupt)) else "FAILED"
            result = StageResult(stage, command, started.isoformat(), utc_timestamp().isoformat(),
                time.monotonic() - monotonic_started, exit_code, status, log_path.name,
                f"{type(stage_error).__name__}: {stage_error}" if stage_error else None)
            results.append(result)
            report["stages"] = [asdict(value) for value in results]
            report["status"] = status if stage_error else "RUNNING"
            if reporter is not None:
                reporter(f"OVERNIGHT END {stage}: status={status}; elapsed={result.elapsed_seconds:.1f}s")
            if stage_error:
                raise stage_error
        report["status"] = "COMPLETE"
        report["current_stage"] = None
    except BaseException as exc:
        error = exc
        if report["status"] == "RUNNING":
            report["status"] = "FAILED"
        report["failed_stage"] = stage
        report["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        report["completed_at"] = utc_timestamp().isoformat()
        report["heartbeat_at"] = report["completed_at"]
        report["total_elapsed_seconds"] = (utc_timestamp(report["completed_at"]) - created).total_seconds()
        _write_json_atomic(report_path, report)
        logs = {path.name: {"size": path.stat().st_size, "checksum_sha256": file_checksum(path)} for path in run.glob("*.log")}
        _write_json_atomic(run / "receipt.json", {
            "schema_version": OVERNIGHT_RUNTIME_VERSION,
            "run_path": run.relative_to(root).as_posix(), "status": report["status"],
            "completed_at": report["completed_at"], "failed_stage": report.get("failed_stage"),
            "stage_report_size": report_path.stat().st_size,
            "stage_report_checksum_sha256": file_checksum(report_path), "logs": logs,
            "broker_orders_enabled": False, "orders_placed": 0,
        })
    if error:
        raise error
    return run


def next_action_deadline(observed_at: object) -> pd.Timestamp:
    local = utc_timestamp(observed_at).tz_convert(SCHEDULE_TIMEZONE)
    label = pd.Timestamp(local.date())
    calendar = xcals.get_calendar("XNYS", start=label - pd.Timedelta(days=10), end=label + pd.Timedelta(days=30))
    session = calendar.date_to_session(label, direction="next")
    if calendar.is_session(label) and local.hour >= 4:
        session = calendar.next_session(session)
    return pd.Timestamp(pd.Timestamp(session).date()).tz_localize(SCHEDULE_TIMEZONE).replace(hour=4).tz_convert("UTC")


def _run_stage(command: Sequence[str], *, repository: Path, log_path: Path,
               deadline: pd.Timestamp, stop_request: Path,
               progress: Callable[[Mapping[str, object]], None], poll_seconds: float) -> int:
    """Stream child output to disk and expose health while long fits continue."""
    if poll_seconds <= 0:
        raise ValueError("poll_seconds must be positive")
    if utc_timestamp() >= deadline:
        raise TimeoutError("Next session's 04:00 PT publication deadline has passed")
    if stop_request.is_file():
        raise InterruptedError("A supervisor stop request was recorded before stage launch")
    environment = dict(os.environ, PYTHONUNBUFFERED="1", DUCKETZ_TRAINING_PROGRESS="1")
    flags = {"creationflags": subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}
    with log_path.open("wb") as output:
        process = subprocess.Popen(command, cwd=repository, stdout=output, stderr=subprocess.STDOUT, env=environment, **flags)
        offset = 0
        issue_count = 0
        issue_tail: list[str] = []
        partial = b""
        try:
            while True:
                now = utc_timestamp()
                with log_path.open("rb") as reader:
                    reader.seek(offset)
                    new = reader.read()
                    offset = reader.tell()
                lines = (partial + new).split(b"\n")
                partial = lines.pop()
                exited = process.poll() is not None
                if exited and partial:
                    lines.append(partial)
                    partial = b""
                text_lines = [line.decode("utf-8", errors="replace").strip() for line in lines]
                issues = [line for line in text_lines if re.search(r"Traceback \(most recent call last\)|\b(ERROR|FAILED|FATAL|FIT_FAILED|FIT_WARNING)\b|(?:ValueError|RuntimeError|MemoryError|Exception):|loss[^\n]*\b(?:nan|inf)\b", line)]
                if issues:
                    issue_count += len(issues)
                    issue_tail = (issue_tail + issues)[-8:]
                payload = {
                    "heartbeat_at": now.isoformat(), "child_pid": process.pid,
                    "child_created_at": _process_created_at(process.pid),
                    "log_bytes": offset, "log_modified_at": pd.Timestamp(log_path.stat().st_mtime, unit="s", tz="UTC").isoformat(),
                    "seconds_to_deadline": max(0, (deadline - now).total_seconds()),
                    "stage_health": "ATTENTION_REQUIRED" if issue_count else "RUNNING",
                    "reported_issue_count": issue_count, "recent_issues": issue_tail,
                    "recent_output": text_lines[-5:],
                }
                payload.update(_process_metrics(process.pid))
                progress(payload)
                if exited:
                    return int(process.returncode)
                if stop_request.is_file():
                    raise InterruptedError(f"Supervisor requested stop: {stop_request.read_text(encoding='utf-8')[:1000]}")
                remaining = (deadline - now).total_seconds()
                if remaining <= 0:
                    raise TimeoutError("Next session's 04:00 PT publication deadline reached")
                try:
                    process.wait(timeout=min(poll_seconds, remaining))
                except subprocess.TimeoutExpired:
                    pass
        except BaseException:
            _terminate_owned_process(process)
            raise


def _process_metrics(pid: int) -> dict[str, object]:
    try:
        import psutil
        process = psutil.Process(pid)
        processes = [process, *process.children(recursive=True)]
        metrics = {"cpu_seconds": 0.0, "memory_bytes": 0, "io_bytes": 0, "process_count": 0}
        for child in processes:
            try:
                cpu = child.cpu_times()
                io = child.io_counters()
                metrics["cpu_seconds"] += cpu.user + cpu.system
                metrics["memory_bytes"] += child.memory_info().rss
                metrics["io_bytes"] += io.read_bytes + io.write_bytes
                metrics["process_count"] += 1
            except psutil.Error:
                continue
        return metrics
    except (ImportError, OSError):
        return {"process_metrics": "unavailable"}
    except Exception as exc:
        return {"process_metrics": type(exc).__name__}


def _process_created_at(pid: int) -> float | None:
    import psutil
    try:
        return psutil.Process(pid).create_time()
    except psutil.NoSuchProcess:
        return None


def recover_interrupted_run(root: Path, run: Path, reason: str) -> Path:
    """Verify terminal recovery or receipt an interrupted, exited owner."""
    import psutil
    run = _validated_run(root, run)
    report_path = run / "stage-report.json"
    report = json.loads(report_path.read_text(encoding="utf-8"))
    terminal = report.get("status") in {"FAILED", "CANCELLED"}
    if not reason.strip():
        raise RuntimeError("Recovery needs an interrupted running attempt and a reason")
    if terminal:
        # The controlled recover/resume procedure also applies when an exited
        # owner already wrote its failure receipt. Reuse that immutable evidence
        # only after exactly the same verification required by resume.
        report = _resume_configuration(root, run)
    elif report.get("status") != "RUNNING" or (run / "receipt.json").exists():
        raise RuntimeError("Recovery needs an interrupted running attempt and a reason")
    owner_created = _process_created_at(int(report["owner_pid"]))
    if owner_created is not None and owner_created == report.get("owner_created_at"):
        raise RuntimeError("Overnight owner is still alive; request a controlled stage stop instead")
    child_pid = report.get("child_pid")
    if terminal:
        child_created = _process_created_at(int(child_pid)) if child_pid else None
        if child_created is not None:
            if child_created != report.get("child_created_at"):
                raise RuntimeError("Child PID was reused; refusing to stop an unrelated process")
            raise RuntimeError("Overnight child is still alive; terminal recovery cannot continue")
        return run
    if child_pid and _process_created_at(int(child_pid)) is not None:
        child = psutil.Process(int(child_pid))
        if child.create_time() != report.get("child_created_at"):
            raise RuntimeError("Child PID was reused; refusing to stop an unrelated process")
        children = child.children(recursive=True)
        for process in [*reversed(children), child]:
            try:
                process.terminate()
            except psutil.NoSuchProcess:
                pass
        _, alive = psutil.wait_procs([*children, child], timeout=10)
        for process in alive:
            process.kill()
        _, alive = psutil.wait_procs(alive, timeout=10)
        if alive:
            raise RuntimeError("Owned child processes did not stop; recovery is incomplete")
    now = utc_timestamp().isoformat()
    completed = {row["stage"] for row in report["stages"] if row["status"] == "COMPLETE"}
    unfinished = [stage for stage in report["stage_order"] if stage not in completed]
    failed_stage = unfinished[0] if unfinished else None
    if failed_stage is not None and failed_stage not in ALL_STAGE_ORDER:
        raise RuntimeError("Interrupted stage cannot be identified")
    status = "CANCELLED" if unfinished else "COMPLETE"
    report.update(status=status, failed_stage=failed_stage, completed_at=now,
                  heartbeat_at=now, error="Supervisor process exited: " + reason)
    _write_json_atomic(report_path, report)
    _write_json_atomic(run / "receipt.json", {
        "schema_version": OVERNIGHT_RUNTIME_VERSION, "run_path": run.relative_to(root).as_posix(),
        "status": status, "completed_at": now, "failed_stage": failed_stage,
        "stage_report_size": report_path.stat().st_size,
        "stage_report_checksum_sha256": file_checksum(report_path),
        "logs": {path.name: {"size": path.stat().st_size, "checksum_sha256": file_checksum(path)} for path in run.glob("*.log")},
        "broker_orders_enabled": False, "orders_placed": 0,
    })
    return run


def _terminate_owned_process(process: subprocess.Popen) -> None:
    if process.poll() is not None:
        return
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], capture_output=True, check=False, timeout=30)
    else:
        os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        if os.name != "nt":
            os.killpg(process.pid, signal.SIGKILL)
        else:
            process.kill()
        process.wait(timeout=10)


def _validated_run(root: Path, run: Path) -> Path:
    run = Path(run).resolve()
    if run.parent != (root / "ml/overnight-runs").resolve():
        raise ValueError("Overnight run escapes its expected directory")
    return run


def _resume_configuration(root: Path, run: Path, *, deadline_exception: Path | None = None,
                          workflow_recovery: Path | None = None,
                          recovery_spec: Path | None = None) -> dict[str, object]:
    run = _validated_run(root, run)
    receipt = json.loads((run / "receipt.json").read_text(encoding="utf-8"))
    report = json.loads((run / "stage-report.json").read_text(encoding="utf-8"))
    if (receipt.get("schema_version") != OVERNIGHT_RUNTIME_VERSION
        or receipt.get("run_path") != run.relative_to(root).as_posix()
        or receipt.get("status") not in {"FAILED", "CANCELLED", "TIMED_OUT"}
        or receipt.get("status") != report.get("status")
        or receipt.get("stage_report_checksum_sha256") != file_checksum(run / "stage-report.json")
        or receipt.get("orders_placed") != 0 or receipt.get("broker_orders_enabled") is not False):
        raise RuntimeError("Only a verified failed or stopped overnight attempt can resume")
    effective_deadline = utc_timestamp(report['deadline_at'])
    exception_original = effective_deadline
    exception_evidence = None
    if recovery_spec is not None and (workflow_recovery is not None or deadline_exception is not None):
        raise ValueError("Use one frozen native recovery route")
    if report.get('recovery') or recovery_spec is not None:
        from ml.nightly_recovery import verify_recovery
        saved = report.get('recovery')
        if recovery_spec is None and deadline_exception is None:
            raise ValueError('Resume must explicitly retain its recovery evidence')
        recovery_path = recovery_spec if recovery_spec is not None else saved["path"]
        stamp = saved["authorization"]["requested_at"] if deadline_exception is not None else utc_timestamp()
        recovery = verify_recovery(root, recovery_path, stamp,
                                   action_date=effective_deadline.tz_convert(SCHEDULE_TIMEZONE).date().isoformat())
        if saved and saved != recovery:
            raise ValueError('Recovery evidence changed since the failed attempt')
        if (recovery['authorization']['source_session'] != report.get('review_action_date')
                or utc_timestamp(recovery['authorization']['original_deadline_at']) != effective_deadline):
            raise ValueError('Recovery differs from the failed session')
        effective_deadline = utc_timestamp(recovery['authorization']['expires_at'])
        exception_original = effective_deadline
    if deadline_exception is not None and report.get("workflow_recovery"):
        from ml.nightly_dispatch import validate_recovery
        saved = report["workflow_recovery"]
        record = json.loads(Path(saved["path"]).read_text(encoding="utf-8"))
        recovery, evidence = validate_recovery(saved["path"], root=root, report=report, run=run,
                                              now=record["approved_at"])
        if evidence != saved:
            raise ValueError("Original scheduled recovery evidence changed before continuation")
        exception_original = utc_timestamp(recovery["expires_at"])
    if workflow_recovery is not None:
        from ml.nightly_dispatch import validate_recovery
        recovery, _ = validate_recovery(workflow_recovery, root=root, report=report, run=run)
        effective_deadline = utc_timestamp(recovery["expires_at"])
    if deadline_exception is not None:
        from ml.preparation_deadline import preparation_deadline
        if (report.get('failed_stage') not in (INDEPENDENT_TRADE_PLANNING_STAGE, INDEPENDENT_ACTUALS_REVIEW_STAGE)
                or report.get('preparation_scope') != 'STOCK_ONLY'
                or report.get('independent_stock_horizons') is not True
                or not report.get('enrichment_gameplan')):
            raise ValueError('Deadline exceptions cover only a pinned stock planning/actuals tail')
        effective_deadline, exception_evidence = preparation_deadline(
            root, root/report['enrichment_gameplan']['run_path'], exception_original, utc_timestamp(), deadline_exception)
        if exception_evidence['authorization']['gameplan_receipt_sha256'] != report['enrichment_gameplan']['receipt_sha256']:
            raise ValueError('Deadline exception differs from the saved tail pin')
    if utc_timestamp() >= effective_deadline:
        raise RuntimeError("The failed attempt's publication deadline has passed")
    for name, record in receipt.get("logs", {}).items():
        path = (run / name).resolve()
        if path.parent != run or file_checksum(path) != record["checksum_sha256"]:
            raise RuntimeError("Failed attempt's log evidence changed")
    completed = list(report.get("completed_stages_from_previous_attempt", []))
    completed.extend(row["stage"] for row in report["stages"] if row["status"] == "COMPLETE")
    if report.get("failed_stage") not in ALL_STAGE_ORDER:
        raise RuntimeError("Failed overnight stage is missing")
    return {**report, "completed_stages": completed, 'effective_deadline_at':effective_deadline.isoformat(),
            'deadline_exception':exception_evidence}


def overnight_status(root: Path) -> dict[str, object]:
    pointer = root / "ml/overnight-latest/run.json"
    if not pointer.is_file():
        return {"status": "NO_RUN", "supervision": _read_supervision(root)}
    run = _validated_run(root, root / json.loads(pointer.read_text(encoding="utf-8"))["run_path"])
    report = json.loads((run / "stage-report.json").read_text(encoding="utf-8"))
    status = {**report, "run_path": str(run), "receipt_present": (run / "receipt.json").is_file(),
              "supervision": _read_supervision(root)}
    if report["status"] == "RUNNING":
        age = (utc_timestamp() - utc_timestamp(report.get("heartbeat_at", report["run_timestamp"]))).total_seconds()
        status["heartbeat_age_seconds"] = age
        if age > 120:
            status["stage_health"] = "SUPERVISOR_HEARTBEAT_STALE"
    return status


def _read_supervision(root: Path) -> dict[str, object]:
    path = root / "ml/overnight-supervision.json"
    if not path.is_file():
        return {"active": False}
    payload = json.loads(path.read_text(encoding="utf-8"))
    return {**payload, "active": utc_timestamp(payload["expires_at"]) > utc_timestamp()}


def claim_supervision(root: Path, token: str, *, release: bool = False,
                      observed_at: object | None = None) -> dict[str, object]:
    """A three-minute renewable lease coordinates Scheduled repair operators."""
    token = str(uuid.UUID(token))
    now = utc_timestamp(observed_at)
    path = root / "ml/overnight-supervision.json"
    with exclusive_runtime_lock(root / ".ducketz-overnight-supervision.lock", process_name="Overnight supervision claim"):
        previous = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
        live = previous and utc_timestamp(previous["expires_at"]) > now
        if previous.get("owner_token") != token and (live or release):
            return {"status": "BUSY" if live else "NOT_OWNER", **previous}
        payload = {"owner_token": token, "updated_at": now.isoformat(),
                   "expires_at": (now if release else now + pd.Timedelta(minutes=3)).isoformat()}
        _write_json_atomic(path, payload)
        return {"status": "RELEASED" if release else "ACQUIRED", **payload}


def request_stage_stop(root: Path, run: Path, reason: str) -> Path:
    run = _validated_run(root, run)
    report = json.loads((run / "stage-report.json").read_text(encoding="utf-8"))
    if report.get("status") != "RUNNING" or (run / "receipt.json").exists():
        raise RuntimeError("Only a running overnight attempt can be stopped")
    if not reason.strip():
        raise ValueError("A stop reason is required")
    request = run / "stop-request.json"
    _write_json_atomic(request, {"requested_at": utc_timestamp().isoformat(), "reason": reason})
    return request


def _write_json_atomic(path: Path, payload: Mapping[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + f".tmp-{os.getpid()}")
    try:
        temporary.write_text(
            json.dumps(dict(payload), indent=2, sort_keys=True, default=str) + "\n",
            encoding="utf-8",
        )
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Run the single post-close owner: fetch, Loop B, Strategy training, "
            "Strategy selection, and immutable gameplan publication."
        )
    )
    datastore = parser.add_mutually_exclusive_group()
    datastore.add_argument("--datastore", type=Path, default=None)
    datastore.add_argument(
        "--datastore-target",
        choices=tuple(DATASTORE_TARGETS),
        default="pc",
    )
    parser.add_argument("--start-at", choices=ALL_STAGE_ORDER, default=STAGE_ORDER[0])
    parser.add_argument("--stop-after", choices=ALL_STAGE_ORDER, default=None)
    parser.add_argument("--resume-run", type=Path, help="Resume the failed stage after a verified repair")
    parser.add_argument(
        "--stock-only", action="store_true",
        help="Prepare stock forecasts without optional Strategy training or generation",
    )
    parser.add_argument("--independent-stock-horizons", action="store_true",
                        help="Publish versioned independent stock entry/exit targets with --stock-only")
    parser.add_argument("--stats-first", action="store_true", default=None,
                        help="Use completed-session Stats before training; stop at gameplan_stats for model review, then start a new training segment")
    parser.add_argument("--review-action-date", help="Completed XNYS session to score; retained on failed-stage resume")
    parser.add_argument("--model-feedback", type=Path, help="Reviewed model proposal consumed by nightly training; exact bytes retained on resume")
    parser.add_argument("--stock-price-source", choices=STOCK_PRICE_SOURCES, default=None,
                        help="Explicit historical equity source for independent stock targets; preserved on resume")
    parser.add_argument("--probability-target-contract", choices=("raw-price-direction-v1", "cost-adjusted-positive-return-v1"),
                        help="Frozen directional target identity; new independent runs use raw direction and resumes retain their saved target")
    parser.add_argument("--status", action="store_true", help="Read the latest overnight progress without starting work")
    parser.add_argument("--archive-history", action="store_true", default=None,
                        help="Use the verified full XNAS feature archive and extend missing minute-label history; preserved on resume")
    parser.add_argument("--request-stop-run", type=Path, help="Ask the owner to stop its current stage")
    parser.add_argument("--recover-run", type=Path, help="Recover an attempt whose supervisor process exited")
    parser.add_argument("--claim-supervision", metavar="UUID", help="Acquire/renew this Scheduled operator's three-minute supervision lease")
    parser.add_argument("--release-supervision", metavar="UUID", help="Release this Scheduled operator's supervision lease")
    parser.add_argument("--reason", default="", help="Evidence-based reason for requesting a stage stop")
    parser.add_argument('--deadline-exception', type=Path, help='Explicit operator-authorized pinned planning/actuals exception record')
    parser.add_argument("--once", action="store_true", help="Compatibility flag")
    parser.add_argument(
        "--scheduled",
        action="store_true",
        help=(
            "Require a completed 17:00 PT XNYS action date; record an audited "
            "no-op on exchange holidays"
        ),
    )
    args = parser.parse_args(argv)
    root = resolve_datastore_dir(
        root_dir=args.datastore,
        target=None if args.datastore is not None else args.datastore_target,
    )
    datastore_argument = (
        ("--datastore", str(args.datastore))
        if args.datastore is not None
        else ("--datastore-target", str(args.datastore_target))
    )
    if args.status:
        print(json.dumps(overnight_status(root), indent=2, default=str))
        return 0
    if args.claim_supervision or args.release_supervision:
        result = claim_supervision(root, args.claim_supervision or args.release_supervision,
                                   release=bool(args.release_supervision))
        print(json.dumps(result))
        return 0
    if args.request_stop_run:
        print(request_stage_stop(root, args.request_stop_run, args.reason))
        return 0
    repository = Path(__file__).resolve().parents[1]
    lock = root / ".ducketz-overnight-runtime.lock"
    with exclusive_runtime_lock(lock, process_name="Duckets overnight runtime"):
        try:
            if args.recover_run:
                print(recover_interrupted_run(root, args.recover_run, args.reason))
                return 0
            if args.scheduled and not args.resume_run:
                eligibility = scheduled_session_eligibility()
                if not bool(eligibility["eligible"]):
                    if eligibility["status"] == "NOOP_NON_SESSION_DATE":
                        run = record_scheduled_noop(
                            root,
                            eligibility=eligibility,
                        )
                        print(
                            "Overnight runtime no-op: "
                            f"{eligibility['reason']} receipt={run}"
                        )
                        return 0
                    raise RuntimeError(str(eligibility["reason"]))
            run = run_overnight_pipeline(
                root,
                datastore_argument=datastore_argument,
                repository_root=repository,
                start_at=args.start_at,
                stop_after=args.stop_after,
                resume_run=args.resume_run,
                stock_only=args.stock_only,
                independent_stock_horizons=args.independent_stock_horizons,
                stock_price_source=args.stock_price_source,
                probability_target_contract=args.probability_target_contract,
                archive_history=args.archive_history,
                deadline_exception=args.deadline_exception,
                stats_first=args.stats_first,
                review_action_date=args.review_action_date,
                model_feedback=args.model_feedback,
            )
        except Exception as exc:
            print(f"Overnight runtime failed: {type(exc).__name__}: {exc}")
            return 1
    print(f"Overnight runtime complete: {run}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "ACTION_DAY_CLOSE_HOUR",
    "OVERNIGHT_NOOP_VERSION",
    "OVERNIGHT_RUNTIME_VERSION",
    "SCHEDULE_TIMEZONE",
    "STAGE_ORDER",
    "StageResult",
    "record_scheduled_noop",
    "run_overnight_pipeline",
    "scheduled_session_eligibility",
    "claim_supervision",
    "next_action_deadline",
    "overnight_status",
    "recover_interrupted_run",
    "request_stage_stop",
]
