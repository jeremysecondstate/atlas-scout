"""Safe, resumable Databento historical cold-start coordinator.

This command is deliberately separate from the seven production supervisors.
It writes only historical bootstrap evidence: OPRA uses the existing canonical
OPRA partition contract, while CME and US-equity data use the same readable
``market-data/databento/<market>/<dataset>`` hierarchy for their baseline and
later overlap windows. It never writes Loop A readiness,
live snapshots, or any ML publication pointer.  After a checksum-verified OPRA
scope completes, it writes the v5 symbol/schema history cursor that hands later
overlap maintenance to the independent Options runtime; that cursor is not
snapshot or live-publication authority.
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import os
import re
import shutil
import sys
import time
import warnings
from collections import Counter
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from datetime import date, datetime, timedelta, timezone
from itertools import count
from pathlib import Path
from typing import Any, Callable, Iterable, Iterator, Mapping, Sequence
from urllib.parse import quote, urlsplit

import pandas as pd
import pyarrow.compute as pc
import pyarrow.parquet as pq
import requests
from requests.auth import HTTPBasicAuth

from app.services.databento_retry import call_with_persistent_databento_retry

from datafetching.cme_runtime import load_repository_environment
from datafetching.databento_history_policy import (
    DEFINITION_LOOKBACK_DAYS,
    heavy_book_lookback_policy,
    interval_lookback_policy,
)
from datafetching.databento_storage import (
    HISTORY_PROFILE,
    MARKET_CME,
    MARKET_OPRA,
    MARKET_US_EQUITIES,
    coordinator_run_directory,
    databento_root,
    dataset_root,
    history_cursor_path,
    request_directory,
)
from datafetching.databento_opra_history import (
    DATASET as OPRA_DATASET,
    SyncScope,
    canonical_root as canonical_opra_root,
    publish_health as publish_opra_health,
    synchronize as synchronize_opra,
)
from datafetching.options_runtime import publish_opra_symbol_history_cursor
from datafetching.parquet_store import DATASTORE_TARGETS, resolve_datastore_dir
from datafetching.runtime_lock import exclusive_runtime_lock
from datafetching.symbol_universe import configured_watchlist_path
from ml.artifacts import file_checksum


COORDINATOR_VERSION = "databento-cold-start-v3"
MANIFEST_VERSION = "databento-cold-start-manifest-v3"
PARTITION_VERSION = "databento-cold-start-partition-v1"
RECEIPT_VERSION = "databento-cold-start-receipt-v1"
PREFLIGHT_VERSION = "databento-cold-start-preflight-v3"
PROGRESS_VERSION = "databento-cold-start-progress-v1"
BATCH_FALLBACK_VERSION = "databento-cold-start-batch-fallback-v1"
STORAGE_RESERVE_BYTES = 5 * 1024**3
STORAGE_EXPANSION_FACTOR = 2
GENERIC_BATCH_FALLBACK_REPEAT_THRESHOLD = 3
GENERIC_BATCH_FALLBACK_SIGNATURE_MAX_BYTES = 1024**2
GENERIC_BATCH_FALLBACK_POLL_SECONDS = 5
DEFAULT_WATCHLIST = configured_watchlist_path()
DEFAULT_EQUITIES_DATASET = "XNAS.ITCH"
COLD_START_EQUITIES_DATASET_ENV = "DATABENTO_COLD_START_EQUITIES_DATASET"
STANDARD_PLAN_AUTHORITY = "docs/databento-plan/databento_standard_plan_data_access.md"
PLAN_DATASET_OPRA = "OPRA"
PLAN_DATASET_CME = "CME"
PLAN_DATASET_US_EQUITIES = "US_EQUITIES"

OPRA_SCHEMAS = (
    "ohlcv-1s",
    "ohlcv-1m",
    "ohlcv-1h",
    "ohlcv-1d",
    "definition",
    "statistics",
    "status",
    "tcbbo",
    "cbbo-1s",
    "cbbo-1m",
    "trades",
)
CME_SCHEMAS = (
    "ohlcv-1s",
    "ohlcv-1m",
    "ohlcv-1h",
    "ohlcv-1d",
    "definition",
    "statistics",
    "status",
    "tbbo",
    "bbo-1s",
    "bbo-1m",
    "trades",
    "mbp-10",
    "mbo",
)
US_EQUITIES_SCHEMAS = (
    "ohlcv-1s",
    "ohlcv-1m",
    "ohlcv-1h",
    "ohlcv-1d",
    "definition",
    "statistics",
    "status",
    "tbbo",
    "bbo-1s",
    "bbo-1m",
    "trades",
    "mbp-10",
    "mbo",
    "imbalance",
)

_SYMBOL_RE = re.compile(r"^[A-Z][A-Z0-9._-]*$")


class ColdStartError(RuntimeError):
    """A cold-start safety contract was not satisfied."""


class ColdStartInfrastructureError(ColdStartError):
    """A systemic execution failure requires the coordinator to stop."""


class ColdStartPublicationError(ColdStartInfrastructureError):
    """A verified staging partition could not be published atomically."""


@dataclass(frozen=True)
class CmeScope:
    symbol: str
    stype_in: str
    source: str


@dataclass(frozen=True)
class ColdStartRequest:
    request_id: str
    dataset: str
    standard_plan_dataset: str
    schema: str
    symbol_scope: tuple[str, ...]
    stype_in: str
    start: str
    end: str
    storage_path: str
    storage_contract: str
    window: Mapping[str, object]
    fetch_mode: str = "initial-baseline"
    baseline_start: str | None = None
    previous_completed_through: str | None = None
    status: str = "PENDING"


def cold_start_root(datastore_root: Path) -> Path:
    return databento_root(datastore_root)


def coordinator_state_root(datastore_root: Path) -> Path:
    return Path(datastore_root).resolve() / "state" / "databento"


def parse_watchlist(path: Path) -> tuple[str, ...]:
    """Read a direct-equity universe without silently accepting ambiguity."""

    try:
        lines = Path(path).read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise ColdStartError(f"Watchlist is unreadable: {path}") from exc
    symbols: list[str] = []
    seen: set[str] = set()
    for number, line in enumerate(lines, start=1):
        value = line.split("#", maxsplit=1)[0].strip().upper()
        if not value:
            continue
        if not _SYMBOL_RE.fullmatch(value) or value.endswith(".OPT"):
            raise ColdStartError(
                f"Watchlist line {number} is not an unambiguous direct equity symbol: {value!r}"
            )
        if value in seen:
            raise ColdStartError(f"Watchlist contains duplicate symbol {value!r}")
        seen.add(value)
        symbols.append(value)
    if not symbols:
        raise ColdStartError("Watchlist contains no direct equity symbols")
    return tuple(symbols)


def opra_parent_symbols(symbols: Iterable[str]) -> tuple[str, ...]:
    parents: list[str] = []
    seen: set[str] = set()
    for value in symbols:
        symbol = str(value).strip().upper()
        if not _SYMBOL_RE.fullmatch(symbol) or symbol.endswith(".OPT"):
            raise ColdStartError(f"Cannot construct an OPRA parent from {value!r}")
        parent = f"{symbol}.OPT"
        if parent in seen:
            raise ColdStartError(f"Ambiguous duplicate OPRA parent scope {parent!r}")
        seen.add(parent)
        parents.append(parent)
    if not parents:
        raise ColdStartError("At least one OPRA parent symbol is required")
    return tuple(parents)


def resolve_cme_scopes(
    environment: Mapping[str, str] | None = None,
    *,
    explicit_symbols: Sequence[str] = (),
    explicit_stype_in: str | None = None,
) -> tuple[CmeScope, ...]:
    """Use configured CME scopes only; never derive CME names from equities."""

    env = os.environ if environment is None else environment
    supplied = tuple(str(value).strip() for value in explicit_symbols if str(value).strip())
    if supplied:
        stype = str(explicit_stype_in or "").strip()
        if not stype or stype == "mixed":
            raise ColdStartError(
                "--cme-symbol requires one explicit non-mixed --cme-stype-in"
            )
        scopes = [CmeScope(_validate_cme_symbol(value), stype, "cli") for value in supplied]
    else:
        context_stype = str(env.get("DATABENTO_CME_CONTEXT_STYPE_IN", "")).strip() or "continuous"
        contract_stype = str(env.get("DATABENTO_CME_CONTRACT_STYPE_IN", "")).strip() or "raw_symbol"
        scopes = [
            CmeScope(_validate_cme_symbol(value), context_stype, "repository-context")
            for value in _split_configured_symbols(env.get("DATABENTO_CME_CONTEXT_SYMBOLS", ""))
        ]
        scopes.extend(
            CmeScope(_validate_cme_symbol(value), contract_stype, "repository-contract")
            for value in _split_configured_symbols(env.get("DATABENTO_CME_CONTRACT_SYMBOLS", ""))
        )
    if not scopes:
        raise ColdStartError(
            "CME cold-start requires explicit CME scope: configure "
            "DATABENTO_CME_CONTEXT_SYMBOLS or DATABENTO_CME_CONTRACT_SYMBOLS, "
            "or pass --cme-symbol with --cme-stype-in. Equity tickers are never CME symbols."
        )
    seen: dict[str, str] = {}
    for scope in scopes:
        previous = seen.get(scope.symbol)
        if previous is not None:
            detail = "different stype_in values" if previous != scope.stype_in else "duplicate entries"
            raise ColdStartError(
                f"Ambiguous CME scope for {scope.symbol!r}: {detail}"
            )
        seen[scope.symbol] = scope.stype_in
    return tuple(sorted(scopes, key=lambda item: (item.symbol, item.stype_in)))


def resolve_equities_dataset(explicit_dataset: str | None = None) -> str:
    """Resolve the cold archive without inheriting Loop A's live dataset."""

    dataset = str(
        explicit_dataset
        or os.environ.get(COLD_START_EQUITIES_DATASET_ENV, "")
        or DEFAULT_EQUITIES_DATASET
    ).strip()
    if not dataset:
        raise ColdStartError("US equities cold-start dataset is required")
    return dataset


def schema_window(standard_plan_dataset: str, schema: str) -> dict[str, object]:
    interval_policy = interval_lookback_policy(schema)
    if interval_policy is not None:
        return interval_policy
    heavy_book_policy = heavy_book_lookback_policy(schema)
    if heavy_book_policy is not None:
        return heavy_book_policy
    if schema == "definition":
        return {"unit": "days", "value": DEFINITION_LOOKBACK_DAYS}
    return {"unit": "calendar_months", "value": 1}


def standard_plan_history_policy(
    standard_plan_dataset: str, schema: str
) -> dict[str, object]:
    if standard_plan_dataset == PLAN_DATASET_OPRA:
        if schema in {"ohlcv-1s", "ohlcv-1m", "ohlcv-1h", "ohlcv-1d", "definition", "statistics", "status"}:
            return {"unit": "years", "value": 13}
        if schema in {"cmbp-1", "tcbbo", "cbbo-1s", "cbbo-1m", "trades"}:
            return {"unit": "months", "value": 12}
    elif standard_plan_dataset == PLAN_DATASET_CME:
        if schema in {"ohlcv-1s", "ohlcv-1m", "ohlcv-1h", "ohlcv-1d", "definition", "statistics", "status"}:
            return {"unit": "years", "value": 16}
        if schema in {"mbp-1", "tbbo", "bbo-1s", "bbo-1m", "trades"}:
            return {"unit": "months", "value": 12}
        if schema in {"mbp-10", "mbo"}:
            return {"unit": "calendar_months", "value": 1}
    elif standard_plan_dataset == PLAN_DATASET_US_EQUITIES:
        if schema in {"ohlcv-1s", "ohlcv-1m", "ohlcv-1h", "ohlcv-1d", "definition", "statistics", "status"}:
            return {"unit": "years", "value": 8}
        if schema in {"mbp-1", "tbbo", "bbo-1s", "bbo-1m", "trades"}:
            return {"unit": "months", "value": 12}
        if schema in {"mbp-10", "mbo", "imbalance"}:
            return {"unit": "calendar_months", "value": 1}
    raise ColdStartError(
        f"No Standard-plan history policy for {standard_plan_dataset}/{schema}"
    )


def required_free_bytes(total_download_payload_bytes: int) -> int:
    if total_download_payload_bytes < 0:
        raise ValueError("Estimated download payload bytes cannot be negative")
    return (
        STORAGE_RESERVE_BYTES
        + STORAGE_EXPANSION_FACTOR * total_download_payload_bytes
    )


def discover_dataset_catalog(
    client: object,
    *,
    dataset: str,
    required_schemas: Sequence[str],
) -> Mapping[str, Mapping[str, str]]:
    """Read provider metadata and fail before requests for unsupported schemas."""

    metadata = getattr(client, "metadata", None)
    if metadata is None:
        raise ColdStartError("Databento client has no metadata endpoint")
    advertised = tuple(_metadata_call(metadata.list_schemas, dataset=dataset))
    missing = sorted(set(required_schemas).difference(str(item) for item in advertised))
    if missing:
        raise ColdStartError(
            f"Databento dataset {dataset} does not support required schemas: {', '.join(missing)}"
        )
    payload = _metadata_call(metadata.get_dataset_range, dataset=dataset)
    if not isinstance(payload, Mapping):
        raise ColdStartError(f"Databento returned malformed dataset range for {dataset}")
    schema_ranges = payload.get("schema")
    if not isinstance(schema_ranges, Mapping):
        raise ColdStartError(f"Databento returned no schema ranges for {dataset}")
    result: dict[str, Mapping[str, str]] = {}
    for schema in required_schemas:
        item = schema_ranges.get(schema)
        if not isinstance(item, Mapping):
            raise ColdStartError(f"Databento returned no range for {dataset}/{schema}")
        start = _as_date(item.get("start"))
        end = _as_date(item.get("end"))
        if start >= end:
            raise ColdStartError(f"Databento returned invalid range for {dataset}/{schema}")
        result[str(schema)] = {"start": start.isoformat(), "end": end.isoformat()}
    return result


def latest_common_available_date(
    catalogs: Mapping[str, Mapping[str, Mapping[str, str]]],
) -> date:
    """Return the latest exclusive date bound supported by every required schema."""

    ends: list[date] = []
    for dataset, schemas in catalogs.items():
        if not schemas:
            raise ColdStartError(f"Databento returned an empty schema catalog for {dataset}")
        for schema, bounds in schemas.items():
            try:
                ends.append(_as_date(bounds["end"]))
            except (KeyError, TypeError) as exc:
                raise ColdStartError(
                    f"Databento returned no end bound for {dataset}/{schema}"
                ) from exc
    if not ends:
        raise ColdStartError("Databento returned no common historical date bound")
    return min(ends)


def build_manifest(
    *,
    datastore_root: Path,
    equities_symbols: Sequence[str],
    cme_dataset: str,
    cme_scopes: Sequence[CmeScope],
    equities_dataset: str,
    as_of: date,
    catalogs: Mapping[str, Mapping[str, Mapping[str, str]]] | None = None,
) -> dict[str, object]:
    """Build a sorted, deterministic request manifest with no provider calls."""

    entries: list[ColdStartRequest] = []
    dataset_specs = (
        (
            OPRA_DATASET,
            PLAN_DATASET_OPRA,
            MARKET_OPRA,
            OPRA_SCHEMAS,
            opra_parent_symbols(equities_symbols),
            "parent",
            "canonical-opra",
        ),
        (
            cme_dataset,
            PLAN_DATASET_CME,
            MARKET_CME,
            CME_SCHEMAS,
            tuple(scope.symbol for scope in cme_scopes),
            "cme",
            "isolated-cold-start",
        ),
        (
            equities_dataset,
            PLAN_DATASET_US_EQUITIES,
            MARKET_US_EQUITIES,
            US_EQUITIES_SCHEMAS,
            tuple(equities_symbols),
            "raw_symbol",
            "isolated-cold-start",
        ),
    )
    cme_stypes = {scope.symbol: scope.stype_in for scope in cme_scopes}
    for (
        dataset,
        standard_plan_dataset,
        market,
        schemas,
        symbols,
        default_stype,
        contract,
    ) in dataset_specs:
        catalog = catalogs.get(dataset) if catalogs else None
        for schema in schemas:
            for symbol in symbols:
                bounds = catalog.get(schema) if catalog else None
                end = as_of
                window = schema_window(standard_plan_dataset, schema)
                baseline_start = _window_start(end, window)
                start = baseline_start
                fetch_mode = "initial-baseline"
                previous_completed_through: str | None = None
                cursor = _read_request_cursor(
                    Path(datastore_root),
                    market=market,
                    dataset=dataset,
                    schema=schema,
                    symbol=symbol,
                )
                if cursor is not None:
                    completed_through = _as_date(cursor["completed_through"])
                    if completed_through < end:
                        start = max(
                            baseline_start,
                            completed_through - timedelta(days=_overlap_days(schema)),
                        )
                        fetch_mode = "overlap-fill"
                        previous_completed_through = completed_through.isoformat()
                if bounds:
                    provider_start = _as_date(bounds["start"])
                    provider_end = _as_date(bounds["end"])
                    if provider_start > start or provider_end < end:
                        raise ColdStartError(
                            f"Provider range does not cover the configured included "
                            f"bootstrap for {dataset}/{schema}: requested="
                            f"{start.isoformat()}..{end.isoformat()} provider="
                            f"{provider_start.isoformat()}..{provider_end.isoformat()}"
                        )
                if start >= end:
                    raise ColdStartError(
                        f"No historical interval remains for {dataset}/{schema}/{symbol}"
                    )
                stype = cme_stypes[symbol] if default_stype == "cme" else default_stype
                storage = _entry_storage_path(
                    Path(datastore_root),
                    dataset=dataset,
                    market=market,
                    schema=schema,
                    symbol=symbol,
                    start=start,
                    end=end,
                    contract=contract,
                )
                identity = {
                    "dataset": dataset,
                    "standard_plan_dataset": standard_plan_dataset,
                    "schema": schema,
                    "symbol_scope": [symbol],
                    "stype_in": stype,
                    "start": start.isoformat(),
                    "end": end.isoformat(),
                    "storage_contract": contract,
                    "window": window,
                    "fetch_mode": fetch_mode,
                    "baseline_start": baseline_start.isoformat(),
                    "previous_completed_through": previous_completed_through,
                }
                entries.append(
                    ColdStartRequest(
                        request_id=_checksum(identity)[:24],
                        storage_path=str(storage),
                        **identity,
                    )
                )
    entries.sort(key=lambda item: (item.dataset, item.schema, item.symbol_scope, item.stype_in))
    body: dict[str, object] = {
        "schema_version": MANIFEST_VERSION,
        "coordinator_version": COORDINATOR_VERSION,
        "history_profile": HISTORY_PROFILE,
        "as_of": as_of.isoformat(),
        "datastore_root": str(Path(datastore_root).resolve()),
        "entitlement_authority": STANDARD_PLAN_AUTHORITY,
        "requests": [asdict(item) for item in entries],
        "derived_views": [],
    }
    _validate_manifest_included_scope(body)
    manifest_id = _checksum(body)[:24]
    return {"manifest_id": manifest_id, **body, "semantic_checksum_sha256": _checksum(body)}


def write_manifest(datastore_root: Path, manifest: Mapping[str, object]) -> Path:
    path = coordinator_run_directory(
        datastore_root,
        as_of=str(manifest["as_of"]),
    ) / "manifest.json"
    if path.is_file():
        try:
            existing = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ColdStartError(f"Existing cold-start manifest is unreadable: {path}") from exc
        if existing.get("semantic_checksum_sha256") != manifest.get("semantic_checksum_sha256"):
            raise ColdStartError(f"Manifest identity collision at {path}")
        return path
    _write_json_exclusive(path, manifest)
    return path


def _validate_manifest_included_scope(manifest: Mapping[str, object]) -> None:
    """Reject any cold-start request outside the documented included scope."""

    try:
        as_of = _as_date(manifest["as_of"])
        requests = manifest["requests"]
    except KeyError as exc:
        raise ColdStartError("Cold-start manifest lacks included-scope metadata") from exc
    if manifest.get("entitlement_authority") != STANDARD_PLAN_AUTHORITY:
        raise ColdStartError("Cold-start manifest has the wrong entitlement authority")
    if not isinstance(requests, list):
        raise ColdStartError("Cold-start manifest has no request list")
    for raw in requests:
        if not isinstance(raw, Mapping):
            raise ColdStartError("Cold-start manifest request is malformed")
        role = str(raw.get("standard_plan_dataset", ""))
        schema = str(raw.get("schema", ""))
        configured_window = schema_window(role, schema)
        if raw.get("window") != configured_window:
            raise ColdStartError(
                f"Cold-start request changed the configured bootstrap window for "
                f"{role}/{schema}"
            )
        start = _as_date(raw.get("start"))
        end = _as_date(raw.get("end"))
        expected_start = _window_start(as_of, configured_window)
        fetch_mode = str(raw.get("fetch_mode", "initial-baseline"))
        baseline_start = _as_date(raw.get("baseline_start", expected_start))
        expected_request_start = expected_start
        if fetch_mode == "overlap-fill":
            previous_completed = _as_date(raw.get("previous_completed_through"))
            if previous_completed >= as_of:
                raise ColdStartError(
                    f"Cold-start overlap cursor is not behind the requested as-of for "
                    f"{role}/{schema}"
                )
            expected_request_start = max(
                expected_start,
                previous_completed - timedelta(days=_overlap_days(schema)),
            )
        elif fetch_mode != "initial-baseline":
            raise ColdStartError(f"Unsupported Databento history fetch mode: {fetch_mode}")
        if (
            baseline_start != expected_start
            or start != expected_request_start
            or end != as_of
        ):
            raise ColdStartError(
                f"Cold-start request does not match the configured baseline/overlap scope "
                f"for {role}/{schema}: requested={start.isoformat()}.."
                f"{end.isoformat()} expected={expected_request_start.isoformat()}.."
                f"{as_of.isoformat()}"
            )
        included_start = _window_start(
            as_of, standard_plan_history_policy(role, schema)
        )
        if start < included_start or end > as_of:
            raise ColdStartError(
                f"Cold-start request is outside the included Standard-plan scope "
                f"for {role}/{schema}: requested={start.isoformat()}.."
                f"{end.isoformat()} included={included_start.isoformat()}.."
                f"{as_of.isoformat()} authority={STANDARD_PLAN_AUTHORITY}"
            )


def preflight_manifest(
    client: object,
    *,
    datastore_root: Path,
    manifest: Mapping[str, object],
    disk_usage: Callable[[str | Path], Any] = shutil.disk_usage,
) -> dict[str, object]:
    """Use exact Databento metadata and calculate the required free capacity."""

    _validate_manifest_included_scope(manifest)
    metadata = getattr(client, "metadata", None)
    if metadata is None:
        raise ColdStartError("Databento client has no metadata endpoint")
    requests = manifest.get("requests")
    if not isinstance(requests, list):
        raise ColdStartError("Cold-start manifest has no request list")
    estimates: list[dict[str, object]] = []
    for raw in requests:
        if not isinstance(raw, Mapping):
            raise ColdStartError("Cold-start manifest request is malformed")
        kwargs = _request_kwargs(raw)
        try:
            estimated_download_size = int(
                _metadata_call(metadata.get_billable_size, **kwargs)
            )
            records = int(_metadata_call(metadata.get_record_count, **kwargs))
        except AttributeError as exc:
            raise ColdStartError(
                "Databento metadata does not support the required download-size "
                "and record-count capacity preflight"
            ) from exc
        if estimated_download_size < 0 or records < 0:
            raise ColdStartError(f"Databento returned negative preflight values for {raw['request_id']}")
        estimates.append(
            {
                "request_id": raw["request_id"],
                "dataset": raw["dataset"],
                "schema": raw["schema"],
                "symbol_scope": list(raw["symbol_scope"]),
                "start": raw["start"],
                "end": raw["end"],
                "record_count": records,
                "estimated_download_size_bytes": estimated_download_size,
            }
        )
    estimates.sort(key=lambda item: (str(item["dataset"]), str(item["schema"]), tuple(item["symbol_scope"])))
    total_download_size = sum(
        int(item["estimated_download_size_bytes"]) for item in estimates
    )
    total_records = sum(int(item["record_count"]) for item in estimates)
    usage = disk_usage(Path(datastore_root).resolve().anchor)
    required = required_free_bytes(total_download_size)
    return {
        "schema_version": PREFLIGHT_VERSION,
        "manifest_id": manifest["manifest_id"],
        "as_of": manifest["as_of"],
        "history_profile": manifest.get("history_profile", HISTORY_PROFILE),
        "generated_at": _utc_now().isoformat(),
        "estimates": estimates,
        "total_estimated_download_size_bytes": total_download_size,
        "total_record_count": total_records,
        "storage_reserve_bytes": STORAGE_RESERVE_BYTES,
        "storage_expansion_factor": STORAGE_EXPANSION_FACTOR,
        "required_free_bytes": required,
        "available_free_bytes": int(usage.free),
        "capacity_pass": int(usage.free) >= required,
        "shortfall_bytes": max(required - int(usage.free), 0),
    }


def write_preflight(datastore_root: Path, preflight: Mapping[str, object]) -> Path:
    path = coordinator_run_directory(
        datastore_root,
        as_of=str(preflight["as_of"]),
    ) / "preflight.json"
    payload = dict(preflight)
    payload["semantic_checksum_sha256"] = _checksum(payload)
    _write_json_atomic(path, payload)
    return path


def _read_json_object(path: Path, *, label: str) -> dict[str, object]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ColdStartError(
            f"Existing {label} was not found: {path}. Run --preflight first."
        ) from exc
    except (OSError, json.JSONDecodeError) as exc:
        raise ColdStartError(f"Existing {label} is unreadable: {path}") from exc
    if not isinstance(payload, dict):
        raise ColdStartError(f"Existing {label} is not a JSON object: {path}")
    return payload


def _validate_manifest_checksum(manifest: Mapping[str, object]) -> None:
    supplied_checksum = str(manifest.get("semantic_checksum_sha256", ""))
    body = {
        key: value
        for key, value in manifest.items()
        if key not in {"manifest_id", "semantic_checksum_sha256"}
    }
    expected_checksum = _checksum(body)
    if supplied_checksum != expected_checksum:
        raise ColdStartError("Existing cold-start manifest checksum verification failed")
    if str(manifest.get("manifest_id", "")) != expected_checksum[:24]:
        raise ColdStartError("Existing cold-start manifest identity verification failed")


def _request_configuration(
    *,
    equities_symbols: Sequence[str],
    cme_dataset: str,
    cme_scopes: Sequence[CmeScope],
    equities_dataset: str,
) -> set[tuple[str, str, str, tuple[str, ...], str]]:
    expected: set[tuple[str, str, str, tuple[str, ...], str]] = set()
    for schema in OPRA_SCHEMAS:
        for symbol in opra_parent_symbols(equities_symbols):
            expected.add(
                (OPRA_DATASET, PLAN_DATASET_OPRA, schema, (symbol,), "parent")
            )
    for schema in CME_SCHEMAS:
        for scope in cme_scopes:
            expected.add(
                (
                    cme_dataset,
                    PLAN_DATASET_CME,
                    schema,
                    (scope.symbol,),
                    scope.stype_in,
                )
            )
    for schema in US_EQUITIES_SCHEMAS:
        for symbol in equities_symbols:
            expected.add(
                (
                    equities_dataset,
                    PLAN_DATASET_US_EQUITIES,
                    schema,
                    (symbol,),
                    "raw_symbol",
                )
            )
    return expected


def _validate_execution_request_identity(
    datastore_root: Path,
    request: Mapping[str, object],
) -> None:
    identity_keys = (
        "dataset",
        "standard_plan_dataset",
        "schema",
        "symbol_scope",
        "stype_in",
        "start",
        "end",
        "storage_contract",
        "window",
        "fetch_mode",
        "baseline_start",
        "previous_completed_through",
    )
    identity = {key: request.get(key) for key in identity_keys}
    if request.get("request_id") != _checksum(identity)[:24]:
        raise ColdStartError("Existing cold-start manifest request identity is invalid")

    role = str(request.get("standard_plan_dataset", ""))
    contract = str(request.get("storage_contract", ""))
    expected_contract = (
        "canonical-opra" if role == PLAN_DATASET_OPRA else "isolated-cold-start"
    )
    if contract != expected_contract:
        raise ColdStartError("Existing cold-start manifest has the wrong storage contract")
    symbols = request.get("symbol_scope")
    if not isinstance(symbols, list) or len(symbols) != 1:
        raise ColdStartError("Existing cold-start manifest request symbol scope is invalid")
    expected_path = _entry_storage_path(
        datastore_root,
        dataset=str(request.get("dataset", "")),
        market=_market_for_plan_dataset(role),
        schema=str(request.get("schema", "")),
        symbol=str(symbols[0]),
        start=_as_date(request.get("start")),
        end=_as_date(request.get("end")),
        contract=contract,
    ).resolve()
    if Path(str(request.get("storage_path", ""))).resolve() != expected_path:
        raise ColdStartError("Existing cold-start manifest request storage path is invalid")


def load_execution_manifest(
    datastore_root: Path,
    *,
    as_of: date,
    equities_symbols: Sequence[str],
    cme_dataset: str,
    cme_scopes: Sequence[CmeScope],
    equities_dataset: str,
) -> tuple[dict[str, object], Path]:
    """Load and verify the immutable manifest selected for execution."""

    path = coordinator_run_directory(
        datastore_root,
        as_of=as_of.isoformat(),
    ) / "manifest.json"
    manifest = _read_json_object(path, label="cold-start manifest")
    _validate_manifest_checksum(manifest)
    if manifest.get("schema_version") != MANIFEST_VERSION:
        raise ColdStartError("Existing cold-start manifest has an unsupported version")
    if manifest.get("coordinator_version") != COORDINATOR_VERSION:
        raise ColdStartError("Existing cold-start manifest belongs to another coordinator version")
    if manifest.get("history_profile") != HISTORY_PROFILE:
        raise ColdStartError("Existing cold-start manifest has the wrong history profile")
    if manifest.get("as_of") != as_of.isoformat():
        raise ColdStartError("Existing cold-start manifest has the wrong as-of date")
    if Path(str(manifest.get("datastore_root", ""))).resolve() != Path(
        datastore_root
    ).resolve():
        raise ColdStartError("Existing cold-start manifest belongs to another datastore")
    if manifest.get("derived_views") != []:
        raise ColdStartError("Existing cold-start manifest unexpectedly contains derived views")
    _validate_manifest_included_scope(manifest)

    requests = manifest.get("requests")
    if not isinstance(requests, list):
        raise ColdStartError("Existing cold-start manifest has no request list")
    actual: set[tuple[str, str, str, tuple[str, ...], str]] = set()
    for request in requests:
        if not isinstance(request, Mapping):
            raise ColdStartError("Existing cold-start manifest request is malformed")
        _validate_execution_request_identity(datastore_root, request)
        symbol_scope = request.get("symbol_scope")
        if not isinstance(symbol_scope, list):
            raise ColdStartError("Existing cold-start manifest symbol scope is malformed")
        actual.add(
            (
                str(request.get("dataset", "")),
                str(request.get("standard_plan_dataset", "")),
                str(request.get("schema", "")),
                tuple(str(symbol) for symbol in symbol_scope),
                str(request.get("stype_in", "")),
            )
        )
    expected = _request_configuration(
        equities_symbols=equities_symbols,
        cme_dataset=cme_dataset,
        cme_scopes=cme_scopes,
        equities_dataset=equities_dataset,
    )
    if len(actual) != len(requests) or actual != expected:
        raise ColdStartError(
            "Existing cold-start manifest does not match the requested watchlist, "
            "datasets, or CME scope; run --preflight for the changed scope"
        )
    return manifest, path


def load_execution_preflight(
    datastore_root: Path,
    *,
    manifest: Mapping[str, object],
    disk_usage: Callable[[str | Path], Any] = shutil.disk_usage,
) -> tuple[dict[str, object], Path]:
    """Verify a saved provider preflight and refresh only local free-space state."""

    path = coordinator_run_directory(
        datastore_root,
        as_of=str(manifest["as_of"]),
    ) / "preflight.json"
    payload = _read_json_object(path, label="cold-start preflight")
    supplied_checksum = str(payload.get("semantic_checksum_sha256", ""))
    checksum_body = {
        key: value
        for key, value in payload.items()
        if key != "semantic_checksum_sha256"
    }
    if supplied_checksum != _checksum(checksum_body):
        raise ColdStartError("Existing cold-start preflight checksum verification failed")
    if payload.get("schema_version") != PREFLIGHT_VERSION:
        raise ColdStartError("Existing cold-start preflight has an unsupported version")
    if payload.get("manifest_id") != manifest.get("manifest_id"):
        raise ColdStartError("Existing preflight does not belong to the selected manifest")
    if payload.get("as_of") != manifest.get("as_of"):
        raise ColdStartError("Existing preflight has the wrong as-of date")
    if payload.get("history_profile") != HISTORY_PROFILE:
        raise ColdStartError("Existing preflight has the wrong history profile")

    requests = manifest.get("requests")
    estimates = payload.get("estimates")
    if not isinstance(requests, list) or not isinstance(estimates, list):
        raise ColdStartError("Existing preflight has no complete estimate list")
    requests_by_id = {
        str(request["request_id"]): request
        for request in requests
        if isinstance(request, Mapping)
    }
    estimates_by_id: dict[str, Mapping[str, object]] = {}
    total_size = 0
    total_records = 0
    for estimate in estimates:
        if not isinstance(estimate, Mapping):
            raise ColdStartError("Existing preflight estimate is malformed")
        request_id = str(estimate.get("request_id", ""))
        request = requests_by_id.get(request_id)
        if request is None or request_id in estimates_by_id:
            raise ColdStartError("Existing preflight estimate coverage is invalid")
        for key in ("dataset", "schema", "symbol_scope", "start", "end"):
            if estimate.get(key) != request.get(key):
                raise ColdStartError(
                    f"Existing preflight estimate does not match request {request_id}"
                )
        try:
            size = int(estimate["estimated_download_size_bytes"])
            records = int(estimate["record_count"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ColdStartError("Existing preflight estimate totals are malformed") from exc
        if size < 0 or records < 0:
            raise ColdStartError("Existing preflight contains a negative provider estimate")
        estimates_by_id[request_id] = estimate
        total_size += size
        total_records += records
    if set(estimates_by_id) != set(requests_by_id):
        raise ColdStartError("Existing preflight is incomplete for the selected manifest")
    if int(payload.get("total_estimated_download_size_bytes", -1)) != total_size:
        raise ColdStartError("Existing preflight download-size total is inconsistent")
    if int(payload.get("total_record_count", -1)) != total_records:
        raise ColdStartError("Existing preflight record-count total is inconsistent")
    if payload.get("storage_reserve_bytes") != STORAGE_RESERVE_BYTES:
        raise ColdStartError("Existing preflight has the wrong storage reserve")
    if payload.get("storage_expansion_factor") != STORAGE_EXPANSION_FACTOR:
        raise ColdStartError("Existing preflight has the wrong storage expansion factor")
    required = required_free_bytes(total_size)
    if int(payload.get("required_free_bytes", -1)) != required:
        raise ColdStartError("Existing preflight required-capacity total is inconsistent")

    usage = disk_usage(Path(datastore_root).resolve().anchor)
    current = dict(payload)
    current["available_free_bytes"] = int(usage.free)
    current["capacity_pass"] = int(usage.free) >= required
    current["shortfall_bytes"] = max(required - int(usage.free), 0)
    return current, path


def execute_manifest(
    client: object,
    *,
    datastore_root: Path,
    manifest: Mapping[str, object],
    preflight: Mapping[str, object],
    reporter: Callable[[str], None] | None = print,
    progress_path: Path | None = None,
) -> dict[str, int]:
    """Fetch only a preflighted manifest and retain durable progress receipts."""

    _validate_manifest_included_scope(manifest)
    if not bool(preflight.get("capacity_pass")):
        raise ColdStartError("Cold-start capacity preflight failed; no downloads were started")
    if preflight.get("manifest_id") != manifest.get("manifest_id"):
        raise ColdStartError("Preflight does not belong to this cold-start manifest")
    estimates = {
        str(item["request_id"]): item
        for item in preflight.get("estimates", [])
        if isinstance(item, Mapping)
    }
    requests = manifest.get("requests")
    if not isinstance(requests, list):
        raise ColdStartError("Cold-start manifest has no request list")
    progress_path = Path(progress_path).resolve() if progress_path is not None else _progress_path(datastore_root, manifest)
    if not progress_path.resolve().is_relative_to(Path(datastore_root).resolve()):
        raise ColdStartError("Cold-start progress path must stay within its datastore")
    progress = _read_progress(progress_path, manifest_id=str(manifest["manifest_id"]))
    counts = {"verified": 0, "downloaded": 0, "no_data": 0, "failed": 0}
    opra_health_pending = False
    for raw in requests:
        if not isinstance(raw, Mapping):
            raise ColdStartError("Cold-start manifest request is malformed")
        is_opra = raw.get("storage_contract") == "canonical-opra"
        if opra_health_pending and not is_opra:
            health_path = publish_opra_health(datastore_root)
            opra_health_pending = False
            if reporter:
                reporter(f"REFRESHED_OPRA_HEALTH {health_path}")
        if is_opra:
            opra_health_pending = True
        request_id = str(raw["request_id"])
        estimate = estimates.get(request_id)
        if estimate is None:
            raise ColdStartError(f"Preflight is incomplete for request {request_id}")
        if int(estimate["record_count"]) == 0:
            _update_progress(progress, raw, status="NO_DATA_VERIFIED", details={"preflight": estimate})
            _write_progress(progress_path, progress)
            _write_request_cursor(
                datastore_root,
                manifest_id=str(manifest["manifest_id"]),
                request=raw,
                status="NO_DATA_VERIFIED",
            )
            counts["no_data"] += 1
            if reporter:
                reporter(f"NO_DATA_VERIFIED {raw['dataset']}/{raw['schema']}/{raw['symbol_scope'][0]}")
            continue
        try:
            if _entry_is_verified(datastore_root, raw):
                status = "VERIFIED_EXISTING"
                counts["verified"] += 1
            elif raw["storage_contract"] == "canonical-opra":
                _execute_opra_entry(
                    client,
                    datastore_root=datastore_root,
                    request=raw,
                    manifest_id=str(manifest["manifest_id"]),
                    reporter=reporter,
                    preflight_estimate=estimate,
                    available_free_bytes=int(preflight["available_free_bytes"]),
                )
                status = "PUBLISHED"
                counts["downloaded"] += 1
            else:
                _download_generic_entry(
                    client,
                    datastore_root=datastore_root,
                    request=raw,
                    reporter=reporter,
                )
                status = "PUBLISHED"
                counts["downloaded"] += 1
            _update_progress(progress, raw, status=status, details={"preflight": estimate})
            _write_progress(progress_path, progress)
            _write_request_cursor(
                datastore_root,
                manifest_id=str(manifest["manifest_id"]),
                request=raw,
                status=status,
            )
            if reporter:
                reporter(f"{status} {raw['dataset']}/{raw['schema']}/{raw['symbol_scope'][0]}")
        except Exception as exc:
            _update_progress(
                progress,
                raw,
                status="FAILED",
                details={"error": f"{type(exc).__name__}: {exc}", "preflight": estimate},
            )
            _write_progress(progress_path, progress)
            counts["failed"] += 1
            if reporter:
                reporter(f"FAILED {raw['dataset']}/{raw['schema']}/{raw['symbol_scope'][0]}: {exc}")
            raise ColdStartInfrastructureError(
                "Cold-start stopped after the first failed request; verified progress "
                "was recorded and the same manifest can be resumed: "
                f"{raw['dataset']}/{raw['schema']}/{raw['symbol_scope'][0]}: "
                f"{type(exc).__name__}: {exc}"
            ) from exc
    if opra_health_pending:
        health_path = publish_opra_health(datastore_root)
        if reporter:
            reporter(f"REFRESHED_OPRA_HEALTH {health_path}")
    return counts


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Plan, preflight, and explicitly execute the isolated Databento historical cold-start. "
            "No downloads occur unless both --execute and --confirm-download are supplied."
        )
    )
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--dry-run", action="store_true", help="Print the deterministic request plan without credentials or network access.")
    mode.add_argument("--preflight", action="store_true", help="Fetch only provider metadata, write the manifest/preflight receipt, and check disk capacity.")
    mode.add_argument("--execute", action="store_true", help="Reuse a verified preflight receipt, then download and publish historical partitions.")
    parser.add_argument(
        "--refresh-preflight",
        action="store_true",
        help="With --execute, explicitly replace the saved receipt using fresh provider metadata.",
    )
    parser.add_argument(
        "--confirm-download",
        action="store_true",
        help="Required with --execute to confirm the included historical transfer.",
    )
    parser.add_argument("--watchlist", type=Path, default=DEFAULT_WATCHLIST)
    parser.add_argument("--as-of", type=_parse_date, default=None, help="Exclusive UTC date bound (YYYY-MM-DD); defaults to today.")
    parser.add_argument(
        "--equities-dataset",
        default=None,
        help=(
            "Cold-archive dataset; defaults to "
            "DATABENTO_COLD_START_EQUITIES_DATASET or XNAS.ITCH."
        ),
    )
    parser.add_argument("--cme-dataset", default=None, help="Defaults to required DATABENTO_CME_DATASET.")
    parser.add_argument("--cme-symbol", action="append", default=[], help="Explicit CME symbol/root. Repeat for multiple symbols.")
    parser.add_argument("--cme-stype-in", default=None, help="Required with --cme-symbol; for example continuous or raw_symbol.")
    datastore = parser.add_mutually_exclusive_group()
    datastore.add_argument("--datastore", type=Path, default=None)
    datastore.add_argument("--datastore-target", choices=tuple(DATASTORE_TARGETS), default=None)
    args = parser.parse_args(argv)
    if args.confirm_download and not args.execute:
        parser.error("--confirm-download is only valid with --execute")
    if args.execute and not args.confirm_download:
        parser.error("--execute requires --confirm-download; no downloads were started")
    if args.refresh_preflight and not args.execute:
        parser.error("--refresh-preflight is only valid with --execute")

    try:
        load_repository_environment()
        root = resolve_datastore_dir(root_dir=args.datastore, target=args.datastore_target)
        equities = parse_watchlist(args.watchlist)
        cme_scopes = resolve_cme_scopes(
            explicit_symbols=args.cme_symbol,
            explicit_stype_in=args.cme_stype_in,
        )
        cme_dataset = str(args.cme_dataset or os.environ.get("DATABENTO_CME_DATASET", "")).strip()
        if not cme_dataset:
            raise ColdStartError(
                "CME cold-start requires DATABENTO_CME_DATASET or --cme-dataset before any request"
            )
        equities_dataset = resolve_equities_dataset(args.equities_dataset)
        if args.dry_run:
            as_of = args.as_of or _utc_now().date()
            manifest = build_manifest(
                datastore_root=root,
                equities_symbols=equities,
                cme_dataset=cme_dataset,
                cme_scopes=cme_scopes,
                equities_dataset=equities_dataset,
                as_of=as_of,
            )
            _print_dry_run(manifest)
            return 0

        api_key = os.environ.get("DATABENTO_API_KEY", "").strip()
        if not api_key:
            raise ColdStartError("DATABENTO_API_KEY is required; no Databento request was started")
        import databento as db

        client = db.Historical(api_key)
        with exclusive_runtime_lock(
            Path(root).resolve() / ".ducketz-databento-cold-start.lock",
            process_name="Duckets Databento cold-start coordinator",
        ):
            if args.execute and not args.refresh_preflight:
                if args.as_of is None:
                    raise ColdStartError(
                        "--execute requires the same explicit --as-of date used by "
                        "--preflight so its saved receipts can be selected without "
                        "provider metadata calls"
                    )
                manifest, manifest_path = load_execution_manifest(
                    root,
                    as_of=args.as_of,
                    equities_symbols=equities,
                    cme_dataset=cme_dataset,
                    cme_scopes=cme_scopes,
                    equities_dataset=equities_dataset,
                )
                preflight, preflight_path = load_execution_preflight(
                    root,
                    manifest=manifest,
                )
                print(
                    "Using checksum-verified saved preflight; provider estimate "
                    "calls were skipped. Current free disk space was rechecked locally."
                )
                _print_preflight(
                    manifest,
                    preflight,
                    manifest_path=manifest_path,
                    preflight_path=preflight_path,
                )
                if not bool(preflight["capacity_pass"]):
                    return 2
                counts = execute_manifest(
                    client,
                    datastore_root=root,
                    manifest=manifest,
                    preflight=preflight,
                )
                print(
                    "Cold-start completed: "
                    + "; ".join(f"{key}={value}" for key, value in counts.items())
                )
                return 0

            catalogs = {
                OPRA_DATASET: discover_dataset_catalog(client, dataset=OPRA_DATASET, required_schemas=OPRA_SCHEMAS),
                cme_dataset: discover_dataset_catalog(client, dataset=cme_dataset, required_schemas=CME_SCHEMAS),
                equities_dataset: discover_dataset_catalog(client, dataset=equities_dataset, required_schemas=US_EQUITIES_SCHEMAS),
            }
            as_of = args.as_of or latest_common_available_date(catalogs)
            manifest = build_manifest(
                datastore_root=root,
                equities_symbols=equities,
                cme_dataset=cme_dataset,
                cme_scopes=cme_scopes,
                equities_dataset=equities_dataset,
                as_of=as_of,
                catalogs=catalogs,
            )
            manifest_path = write_manifest(root, manifest)
            preflight = preflight_manifest(client, datastore_root=root, manifest=manifest)
            preflight_path = write_preflight(root, preflight)
            _print_preflight(manifest, preflight, manifest_path=manifest_path, preflight_path=preflight_path)
            if not bool(preflight["capacity_pass"]):
                return 2
            if args.preflight:
                return 0
            counts = execute_manifest(client, datastore_root=root, manifest=manifest, preflight=preflight)
            print("Cold-start completed: " + "; ".join(f"{key}={value}" for key, value in counts.items()))
            return 0
    except ColdStartError as exc:
        print(f"Databento cold-start blocked: {exc}", file=sys.stderr)
        return 2
    except Exception as exc:  # pragma: no cover - defensive CLI boundary
        print(f"Databento cold-start failed closed: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


def _execute_opra_entry(
    client: object,
    *,
    datastore_root: Path,
    request: Mapping[str, object],
    manifest_id: str,
    reporter: Callable[[str], None] | None,
    preflight_estimate: Mapping[str, object] | None = None,
    available_free_bytes: int | None = None,
) -> None:
    schema = str(request["schema"])
    symbol = str(request["symbol_scope"][0])
    catalog = {
        "entitlements": {
            schema: {
                "level": "historical",
                "dataset_start": str(request["start"]),
                "entitled_start": str(request["start"]),
                "entitled_end": str(request["end"]),
            }
        }
    }
    # The existing OPRA writer owns the canonical path and its history sync
    # lock. This preserves Options Capture's forward-maintenance authority.
    with exclusive_runtime_lock(
        canonical_opra_root(datastore_root) / "state" / "sync.lock",
        process_name="Duckets cold-start OPRA history synchronizer",
    ):
        storage_preflight_receipt: Mapping[str, object] | None = None
        if preflight_estimate is not None and available_free_bytes is not None:
            estimated_size = int(preflight_estimate["estimated_download_size_bytes"])
            record_count = int(preflight_estimate["record_count"])
            required = required_free_bytes(estimated_size)
            storage_preflight_receipt = {
                "schema_version": "databento-opra-storage-preflight-v2",
                "provider": "databento-opra",
                "dataset": OPRA_DATASET,
                "scope": {
                    "schemas": [schema],
                    "symbols": [symbol],
                    "start": str(request["start"]),
                    "end": str(request["end"]),
                },
                "estimates": {
                    schema: {
                        "start": str(request["start"]),
                        "end": str(request["end"]),
                        "symbols": [symbol],
                        "estimated_download_size_bytes": estimated_size,
                        "record_count": record_count,
                    }
                },
                "estimated_download_size_bytes": estimated_size,
                "record_count": record_count,
                "storage_expansion_factor": float(STORAGE_EXPANSION_FACTOR),
                "storage_reserve_bytes": STORAGE_RESERVE_BYTES,
                "required_free_bytes": required,
                "available_free_bytes": available_free_bytes,
                "capacity_pass": available_free_bytes >= required,
                "shortfall_bytes": max(required - available_free_bytes, 0),
                "source": "checksum-verified cold-start coordinator preflight",
            }
        result = synchronize_opra(
            client,
            datastore_root=datastore_root,
            entitlement=catalog,
            scope=SyncScope(
                schemas=(schema,),
                start=str(request["start"]),
                end=str(request["end"]),
                symbols=(symbol,),
            ),
            reporter=reporter,
            storage_preflight_receipt=storage_preflight_receipt,
            fail_fast=True,
            batch_download=True,
            refresh_health=False,
        )
        if result.errors or result.completed_rows < 1:
            raise ColdStartError(
                f"Canonical OPRA synchronization was not completely verified for {schema}/{symbol}; "
                f"errors={len(result.errors)} rows={result.completed_rows}"
            )
        underlying = symbol.removesuffix(".OPT")
        cursor_policy = dict(request["window"])
        if cursor_policy.get("unit") == "calendar_months":
            cursor_policy["unit"] = "months"
        publish_opra_symbol_history_cursor(
            datastore_root,
            symbol=underlying,
            schema=schema,
            requested_start=str(request["start"]),
            completed_through=str(request["end"]),
            lookback_policy=cursor_policy,
            bootstrap_manifest_id=manifest_id,
        )


def _download_generic_entry(
    client: object,
    *,
    datastore_root: Path,
    request: Mapping[str, object],
    reporter: Callable[[str], None] | None = print,
    _retry_sleeper: Callable[[float], None] = time.sleep,
) -> None:
    destination, staging_base = _generic_entry_paths(datastore_root, request)
    if destination.exists():
        _verify_generic_partition(destination, request)
        return
    if _publish_recoverable_generic_staging(
        staging_base,
        destination=destination,
        request=request,
    ):
        return
    batch_api = _generic_batch_api(client)
    retained_repeat_count = _repeated_small_partial_count(staging_base)
    if batch_api is not None and (
        _batch_fallback_state_path(staging_base).is_file()
        or retained_repeat_count >= GENERIC_BATCH_FALLBACK_REPEAT_THRESHOLD
    ):
        if reporter:
            reporter(
                "USING_BATCH_FALLBACK "
                f"{request['dataset']}/{request['schema']}/"
                f"{request['symbol_scope'][0]}; retained_matching_partials="
                f"{retained_repeat_count}"
            )
        _download_generic_batch_fallback(
            client,
            staging_base=staging_base,
            destination=destination,
            request=request,
            reporter=reporter,
            _poll_sleeper=_retry_sleeper,
        )
        return
    try:
        _download_generic_attempt(
            client,
            staging_base=staging_base,
            destination=destination,
            request=request,
            reporter=reporter,
            retry_sleeper=_retry_sleeper,
            batch_available=batch_api is not None,
        )
    except _UseBatchFallback:
        _download_generic_batch_fallback(
            client,
            staging_base=staging_base,
            destination=destination,
            request=request,
            reporter=reporter,
            _poll_sleeper=_retry_sleeper,
        )


class _UseBatchFallback(Exception):
    """Leave the stream retry boundary before any batch submission."""


@contextmanager
def _capture_provider_warnings(
    provider_warnings: list[dict[str, str]],
) -> Iterator[None]:
    """Keep provider warnings visible while retaining them for partition audit."""

    original_showwarning = warnings.showwarning

    def record_and_show_warning(
        message: Warning | str,
        category: type[Warning],
        filename: str,
        lineno: int,
        file: Any = None,
        line: str | None = None,
    ) -> None:
        warning = {
            "category": f"{category.__module__}.{category.__name__}",
            "message": str(message),
        }
        if warning not in provider_warnings:
            provider_warnings.append(warning)
        original_showwarning(message, category, filename, lineno, file=file, line=line)

    with warnings.catch_warnings():
        warnings.simplefilter("always")
        warnings.showwarning = record_and_show_warning
        yield


def _download_generic_attempt(
    client: object,
    *,
    staging_base: Path,
    destination: Path,
    request: Mapping[str, object],
    reporter: Callable[[str], None] | None,
    retry_sleeper: Callable[[float], None],
    batch_available: bool,
) -> None:
    """Retry the remote stream, then validate and publish outside that boundary."""

    staging: Path | None = None
    provider_warnings: list[dict[str, str]] = []
    store: object | None = None

    def fetch() -> object:
        nonlocal staging
        provider_warnings.clear()
        staging = _next_attempt_directory(staging_base)
        staging.mkdir(parents=True, exist_ok=False)
        kwargs = _request_kwargs(request)
        kwargs["path"] = staging / "provider.dbn.zst"
        with _capture_provider_warnings(provider_warnings):
            return getattr(client, "timeseries").get_range(**kwargs)

    def before_retry(_exc: Exception, attempt: int) -> None:
        # Failed partials are retained. Release SDK reader handles before the
        # next request, including when repeated truncation selects batch mode.
        gc.collect()
        if (batch_available and _repeated_small_partial_count(staging_base)
                >= GENERIC_BATCH_FALLBACK_REPEAT_THRESHOLD):
            if reporter:
                reporter(
                    "USING_BATCH_FALLBACK "
                    f"{request['dataset']}/{request['schema']}/"
                    f"{request['symbol_scope'][0]} after {attempt} truncated stream attempts"
                )
            raise _UseBatchFallback

    try:
        store = call_with_persistent_databento_retry(
            fetch,
            operation_name="timeseries.get_range",
            sleep=retry_sleeper,
            reporter=reporter,
            before_retry=before_retry,
            symbol=str(request["symbol_scope"][0]),
            schema=str(request["schema"]),
            request_start=request["start"],
            request_end=request["end"],
        )
        assert staging is not None
        raw_path = staging / "provider.dbn.zst"
        if not raw_path.is_file() or raw_path.stat().st_size == 0:
            raise ColdStartError("Databento did not produce a provider-native DBN file")
        if store is None:
            store = _dbn_store_from_file(raw_path)
        store.to_parquet(staging / "normalized.parquet", map_symbols=True)
    finally:
        # DBNStore retains its source handle on Windows. Conversion/publication
        # failures and cancellation never re-enter the remote retry boundary.
        store = None
        gc.collect()

    _publish_generic_attempt(
        staging=staging,
        destination=destination,
        request=request,
        provider_warnings=provider_warnings,
        provider_delivery={"mode": "timeseries-stream"},
    )


def _publish_generic_attempt(
    *,
    staging: Path,
    destination: Path,
    request: Mapping[str, object],
    provider_warnings: Sequence[Mapping[str, str]],
    provider_delivery: Mapping[str, object],
) -> None:
    """Validate normalized output, write evidence, and atomically publish it."""

    raw_path = staging / "provider.dbn.zst"
    parquet_path = staging / "normalized.parquet"
    if not parquet_path.is_file():
        raise ColdStartError("Databento DBN normalization produced no Parquet")
    validation = _validate_generic_parquet(parquet_path, request)
    manifest = {
        "schema_version": PARTITION_VERSION,
        "coordinator_version": COORDINATOR_VERSION,
        "request": dict(request),
        "published_at": _utc_now().isoformat(),
        "provider_warnings": [dict(item) for item in provider_warnings],
        "provider_delivery": dict(provider_delivery),
        "raw": {
            "path": raw_path.name,
            "size_bytes": raw_path.stat().st_size,
            "checksum_sha256": file_checksum(raw_path),
        },
        "normalized": {
            "path": parquet_path.name,
            "size_bytes": parquet_path.stat().st_size,
            "checksum_sha256": file_checksum(parquet_path),
            **validation,
        },
    }
    manifest_path = staging / "manifest.json"
    _write_json_exclusive(manifest_path, manifest)
    receipt = {
        "schema_version": RECEIPT_VERSION,
        "request_id": request["request_id"],
        "manifest_checksum_sha256": file_checksum(manifest_path),
        "raw_checksum_sha256": manifest["raw"]["checksum_sha256"],
        "normalized_checksum_sha256": manifest["normalized"]["checksum_sha256"],
        "published_at": manifest["published_at"],
    }
    _write_json_exclusive(staging / "receipt.json", receipt)
    _verify_generic_partition(staging, request)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        _verify_generic_partition(destination, request)
        return
    try:
        staging.replace(destination)
    except OSError as exc:
        raise ColdStartPublicationError(
            f"Verified staging could not be published: {staging} -> {destination}: {exc}"
        ) from exc
    _verify_generic_partition(destination, request)


def _generic_batch_api(client: object) -> object | None:
    batch_api = getattr(client, "batch", None)
    required = ("submit_job", "get_job_details", "list_files", "download")
    if batch_api is None or not all(
        callable(getattr(batch_api, name, None)) for name in required
    ):
        return None
    return batch_api


def _repeated_small_partial_count(staging_base: Path) -> int:
    """Count matching incomplete responses without hashing potentially huge files."""

    if not staging_base.is_dir():
        return 0
    signatures: Counter[tuple[int, str]] = Counter()
    for candidate in sorted(staging_base.glob("attempt-*")):
        if not candidate.is_dir() or (candidate / "manifest.json").exists():
            continue
        raw_path = candidate / "provider.dbn.zst"
        try:
            size = raw_path.stat().st_size
        except OSError:
            continue
        if size < 1 or size > GENERIC_BATCH_FALLBACK_SIGNATURE_MAX_BYTES:
            continue
        try:
            signatures[(size, file_checksum(raw_path))] += 1
        except OSError:
            continue
    return max(signatures.values(), default=0)


def _batch_fallback_state_path(staging_base: Path) -> Path:
    return staging_base / "batch-fallback.json"


def _load_batch_fallback_state(
    staging_base: Path,
    request: Mapping[str, object],
) -> dict[str, object] | None:
    path = _batch_fallback_state_path(staging_base)
    if not path.is_file():
        return None
    payload = _read_json_object(path, label="Databento batch fallback state")
    supplied_checksum = str(payload.get("semantic_checksum_sha256", ""))
    body = {
        key: value
        for key, value in payload.items()
        if key != "semantic_checksum_sha256"
    }
    if (
        payload.get("schema_version") != BATCH_FALLBACK_VERSION
        or payload.get("request_id") != request.get("request_id")
        or payload.get("request_checksum_sha256") != _checksum(dict(request))
        or supplied_checksum != _checksum(body)
        or not _safe_batch_component(str(payload.get("job_id", "")))
    ):
        raise ColdStartError(
            f"Databento batch fallback state does not match request: {path}"
        )
    return payload


def _load_or_submit_batch_fallback(
    batch_api: object,
    *,
    staging_base: Path,
    request: Mapping[str, object],
    reporter: Callable[[str], None] | None,
) -> str:
    existing = _load_batch_fallback_state(staging_base, request)
    if existing is not None:
        job_id = str(existing["job_id"])
        if reporter:
            reporter(f"BATCH_FALLBACK_RESUMED job_id={job_id}")
        return job_id

    # A failed/ interrupted POST can have succeeded remotely. Preserve intent
    # before sending so a later resume cannot blindly create a duplicate job.
    intent_path = staging_base / "batch-submission-intent.json"
    if intent_path.exists():
        raise ColdStartInfrastructureError(
            "Databento batch submission outcome is unconfirmed; preserve the "
            "submission intent and reconcile its job ID before resubmission"
        )
    intent = {
        "schema_version": "databento-cold-start-batch-submission-intent-v1",
        "request_id": request["request_id"],
        "request_checksum_sha256": _checksum(dict(request)),
        "started_at": _utc_now().isoformat(),
    }
    intent["semantic_checksum_sha256"] = _checksum(intent)
    _write_json_exclusive(intent_path, intent)
    try:
        response = getattr(batch_api, "submit_job")(
            dataset=request["dataset"],
            schema=request["schema"],
            symbols=list(request["symbol_scope"]),
            stype_in=request["stype_in"],
            start=request["start"],
            end=request["end"],
            encoding="dbn",
            compression="zstd",
            map_symbols=False,
            split_symbols=False,
            split_duration="none",
            delivery="download",
        )
    except Exception as exc:
        raise ColdStartInfrastructureError(
            "Databento batch submission outcome is unconfirmed; preserve the "
            "submission intent and reconcile its job ID before resubmission"
        ) from exc
    if not isinstance(response, Mapping) or not str(response.get("id", "")).strip():
        raise ColdStartInfrastructureError(
            "Databento batch fallback submission returned no job ID"
        )
    job_id = str(response["id"]).strip()
    if not _safe_batch_component(job_id):
        raise ColdStartInfrastructureError("Databento returned an unsafe batch job ID")
    state = {
        "schema_version": BATCH_FALLBACK_VERSION,
        "request_id": request["request_id"],
        "request_checksum_sha256": _checksum(dict(request)),
        "job_id": job_id,
        "submitted_at": _utc_now().isoformat(),
    }
    state["semantic_checksum_sha256"] = _checksum(state)
    _write_json_exclusive(_batch_fallback_state_path(staging_base), state)
    if reporter:
        reporter(f"BATCH_FALLBACK_SUBMITTED job_id={job_id}")
    return job_id


def _wait_for_batch_fallback(
    batch_api: object,
    *,
    job_id: str,
    reporter: Callable[[str], None] | None,
    sleeper: Callable[[float], None],
) -> Mapping[str, object]:
    last_report: tuple[str, object] | None = None
    while True:
        details = call_with_persistent_databento_retry(
            lambda: getattr(batch_api, "get_job_details")(job_id),
            operation_name="batch.get_job_details",
            sleep=sleeper,
            reporter=reporter,
        )
        if not isinstance(details, Mapping):
            raise ColdStartInfrastructureError(
                f"Databento batch job {job_id} returned malformed details"
            )
        state = str(details.get("state", "")).strip().casefold()
        progress = details.get("progress")
        if state == "done":
            if reporter:
                reporter(f"BATCH_FALLBACK_READY job_id={job_id}")
            return details
        if state == "expired":
            raise ColdStartInfrastructureError(
                f"Databento batch fallback job expired before publication: {job_id}"
            )
        if state not in {"received", "queued", "processing"}:
            raise ColdStartInfrastructureError(
                f"Databento batch fallback job has unexpected state {state!r}: {job_id}"
            )
        report = (state, progress)
        if reporter and report != last_report:
            reporter(
                f"BATCH_FALLBACK_WAITING job_id={job_id} "
                f"state={state} progress={progress}"
            )
        last_report = report
        sleeper(float(GENERIC_BATCH_FALLBACK_POLL_SECONDS))


def _download_batch_fallback_file(
    batch_api: object,
    *,
    staging_base: Path,
    job_id: str,
    sleeper: Callable[[float], None] = time.sleep,
    reporter: Callable[[str], None] | None = print,
) -> tuple[Path, Mapping[str, object]]:
    files = call_with_persistent_databento_retry(
        lambda: getattr(batch_api, "list_files")(job_id),
        operation_name="batch.list_files",
        sleep=sleeper,
        reporter=reporter,
    )
    if not isinstance(files, list):
        raise ColdStartInfrastructureError(
            f"Databento batch job {job_id} returned a malformed file list"
        )
    data_files = [
        item
        for item in files
        if isinstance(item, Mapping)
        and str(item.get("filename", "")).casefold().endswith(".dbn.zst")
    ]
    if len(data_files) != 1:
        raise ColdStartInfrastructureError(
            f"Databento batch fallback expected one DBN file but found {len(data_files)}: "
            f"{job_id}"
        )
    file_info = data_files[0]
    filename = str(file_info.get("filename", "")).strip()
    if not _safe_batch_component(filename):
        raise ColdStartInfrastructureError(
            f"Databento batch job {job_id} returned an unsafe filename"
        )
    expected_size = file_info.get("size")
    if isinstance(expected_size, bool) or not isinstance(expected_size, int) or expected_size < 1:
        raise ColdStartInfrastructureError(
            f"Databento batch job {job_id} returned no valid DBN size"
        )
    provider_hash = str(file_info.get("hash", ""))
    algorithm, separator, expected_hash = provider_hash.partition(":")
    if (algorithm.casefold() != "sha256" or not separator
            or re.fullmatch(r"[0-9a-fA-F]{64}", expected_hash) is None):
        raise ColdStartInfrastructureError(
            f"Databento batch job {job_id} returned no SHA-256 DBN checksum"
        )

    def download() -> Path:
        attempt = _next_attempt_directory(staging_base / "batch-downloads")
        attempt.mkdir(parents=True, exist_ok=False)
        target = attempt / filename
        _download_batch_file_once(batch_api, job_id=job_id, filename=filename, target=target)
        return target

    source = call_with_persistent_databento_retry(
        download,
        operation_name="batch.download",
        sleep=sleeper,
        reporter=reporter,
    )
    if (
        not source.is_file()
        or source.stat().st_size != expected_size
        or file_checksum(source).casefold() != expected_hash.casefold()
    ):
        raise ColdStartInfrastructureError(
            f"Databento batch DBN checksum verification failed: {source}"
        )
    return source, file_info


def _safe_batch_component(value: str) -> bool:
    return bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", value))


def _download_batch_file_once(
    batch_api: object, *, job_id: str, filename: str, target: Path,
) -> None:
    """One authenticated GET, with no SDK-internal retry or URL redirection."""
    gateway = str(getattr(batch_api, "_gateway", "")).rstrip("/")
    base_url = str(getattr(batch_api, "_base_url", ""))
    parsed = urlsplit(base_url)
    if (gateway != "https://hist.databento.com"
            or parsed.scheme != "https" or parsed.netloc != "hist.databento.com"
            or parsed.query or parsed.fragment
            or re.fullmatch(r"/v[0-9]+/batch", parsed.path) is None
            or not _safe_batch_component(job_id) or not _safe_batch_component(filename)):
        raise ColdStartInfrastructureError("Unsafe Databento batch download endpoint or component")
    url = f"{base_url}/download/{quote(job_id, safe='')}/{quote(filename, safe='')}"
    key = getattr(batch_api, "_key", None)
    if not isinstance(key, str) or not key:
        raise ColdStartInfrastructureError("Existing Databento batch authentication is unavailable")
    # Only this fixed origin receives the existing client's authentication.
    # Opening/writing locally is outside requests' exception conversion.
    with target.open("xb") as handle:
        with requests.get(
            url, auth=HTTPBasicAuth(key, ""), stream=True,
            timeout=(100, 100), allow_redirects=False,
        ) as response:
            if 300 <= response.status_code < 400:
                raise ColdStartInfrastructureError("Databento batch redirects are not permitted")
            response.raise_for_status()
            for chunk in response.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    handle.write(chunk)


def _dbn_store_from_file(path: Path) -> object:
    import databento as db

    return db.DBNStore.from_file(path)


def _download_generic_batch_fallback(
    client: object,
    *,
    staging_base: Path,
    destination: Path,
    request: Mapping[str, object],
    reporter: Callable[[str], None] | None,
    _poll_sleeper: Callable[[float], None] = time.sleep,
) -> None:
    """Submit or resume one exact batch job, then verify and publish its DBN."""

    batch_api = _generic_batch_api(client)
    if batch_api is None:
        raise ColdStartInfrastructureError(
            "Installed Databento client does not provide the required batch fallback API"
        )
    provider_warnings: list[dict[str, str]] = []
    with _capture_provider_warnings(provider_warnings):
        job_id = _load_or_submit_batch_fallback(
            batch_api,
            staging_base=staging_base,
            request=request,
            reporter=reporter,
        )
        _wait_for_batch_fallback(
            batch_api,
            job_id=job_id,
            reporter=reporter,
            sleeper=_poll_sleeper,
        )
        source, file_info = _download_batch_fallback_file(
            batch_api,
            staging_base=staging_base,
            job_id=job_id,
            sleeper=_poll_sleeper,
            reporter=reporter,
        )

    staging = _next_attempt_directory(staging_base)
    staging.mkdir(parents=True, exist_ok=False)
    raw_path = staging / "provider.dbn.zst"
    parquet_path = staging / "normalized.parquet"
    try:
        shutil.copy2(source, raw_path)
    except OSError as exc:
        raise ColdStartInfrastructureError(
            f"Unable to copy verified Databento batch DBN into staging: {exc}"
        ) from exc
    store: object | None = None
    try:
        store = _dbn_store_from_file(raw_path)
        getattr(store, "to_parquet")(parquet_path, map_symbols=True)
    finally:
        store = None
        gc.collect()

    _publish_generic_attempt(
        staging=staging,
        destination=destination,
        request=request,
        provider_warnings=provider_warnings,
        provider_delivery={
            "mode": "batch",
            "job_id": job_id,
            "filename": file_info["filename"],
            "provider_hash": file_info["hash"],
        },
    )


def _generic_entry_paths(
    datastore_root: Path,
    request: Mapping[str, object],
) -> tuple[Path, Path]:
    """Resolve final/staging paths and reject any path outside Databento storage."""

    root = cold_start_root(datastore_root).resolve()
    destination = Path(str(request["storage_path"])).resolve()
    try:
        destination_relative = destination.relative_to(root)
    except ValueError as exc:
        raise ColdStartError(
            f"Cold-start destination escapes the Databento root: {destination}"
        ) from exc
    staging_root = (root / ".staging").resolve()
    staging_base = (staging_root / destination_relative).resolve()
    try:
        staging_base.relative_to(staging_root)
    except ValueError as exc:  # pragma: no cover - defensive against path semantics
        raise ColdStartError(
            f"Cold-start staging path escapes the Databento staging root: {staging_base}"
        ) from exc
    return destination, staging_base


def _publish_recoverable_generic_staging(
    staging_base: Path,
    *,
    destination: Path,
    request: Mapping[str, object],
) -> bool:
    """Publish a complete retained attempt before requesting the data again."""

    if not staging_base.is_dir():
        return False
    resolved_base = staging_base.resolve()
    for candidate in sorted(staging_base.glob("attempt-*")):
        if not candidate.is_dir():
            continue
        resolved_candidate = candidate.resolve()
        try:
            resolved_candidate.relative_to(resolved_base)
        except ValueError as exc:
            raise ColdStartError(
                f"Retained staging attempt escapes its request root: {candidate}"
            ) from exc
        try:
            _verify_generic_partition(resolved_candidate, request)
        except ColdStartError:
            continue
        # Verification reads Parquet and checksums before publication. Ensure
        # all transient reader objects are finalized before the Windows rename.
        gc.collect()
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            _verify_generic_partition(destination, request)
            return True
        try:
            resolved_candidate.replace(destination)
        except OSError as exc:
            raise ColdStartPublicationError(
                "Verified retained staging could not be published: "
                f"{resolved_candidate} -> {destination}: {exc}"
            ) from exc
        _verify_generic_partition(destination, request)
        return True
    return False


def _entry_is_verified(datastore_root: Path, request: Mapping[str, object]) -> bool:
    if request["storage_contract"] == "canonical-opra":
        # Re-run the canonical synchronizer on resume.  It verifies each stored
        # partition before skipping it and catches any damaged receipt.
        return False
    destination, _staging_base = _generic_entry_paths(datastore_root, request)
    if not destination.is_dir():
        return False
    _verify_generic_partition(destination, request)
    return True


def _verify_generic_partition(directory: Path, request: Mapping[str, object]) -> None:
    try:
        manifest_path = directory / "manifest.json"
        receipt_path = directory / "receipt.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ColdStartError(f"Cold-start partition metadata is unreadable: {directory}") from exc
    if (
        manifest.get("schema_version") != PARTITION_VERSION
        or receipt.get("schema_version") != RECEIPT_VERSION
        or receipt.get("request_id") != request.get("request_id")
        or receipt.get("manifest_checksum_sha256") != file_checksum(manifest_path)
        or manifest.get("request") != dict(request)
    ):
        raise ColdStartError(f"Cold-start partition receipt does not match request: {directory}")
    provider_delivery = manifest.get("provider_delivery")
    if provider_delivery is not None:
        if not isinstance(provider_delivery, Mapping) or provider_delivery.get("mode") not in {
            "timeseries-stream",
            "batch",
        }:
            raise ColdStartError(
                f"Cold-start partition has invalid provider delivery evidence: {directory}"
            )
        if provider_delivery.get("mode") == "batch" and (
            not str(provider_delivery.get("job_id", "")).strip()
            or not str(provider_delivery.get("filename", "")).strip()
            or not str(provider_delivery.get("provider_hash", ""))
            .casefold()
            .startswith("sha256:")
        ):
            raise ColdStartError(
                f"Cold-start partition has incomplete batch delivery evidence: {directory}"
            )
    for name in ("raw", "normalized"):
        info = manifest.get(name)
        if not isinstance(info, Mapping):
            raise ColdStartError(f"Cold-start partition lacks {name} evidence: {directory}")
        path = directory / str(info.get("path"))
        if (
            not path.is_file()
            or path.stat().st_size != int(info.get("size_bytes", -1))
            or file_checksum(path) != info.get("checksum_sha256")
        ):
            raise ColdStartError(f"Cold-start {name} checksum verification failed: {directory}")
    if isinstance(provider_delivery, Mapping) and provider_delivery.get("mode") == "batch":
        _algorithm, _separator, provider_hash = str(
            provider_delivery["provider_hash"]
        ).partition(":")
        if (
            manifest["raw"].get("checksum_sha256", "").casefold()
            != provider_hash.casefold()
        ):
            raise ColdStartError(
                f"Cold-start batch provider checksum verification failed: {directory}"
            )
    validation = _validate_generic_parquet(directory / str(manifest["normalized"]["path"]), request)
    for key in ("row_count", "earliest_timestamp", "latest_timestamp", "timestamp_column"):
        if validation.get(key) != manifest["normalized"].get(key):
            raise ColdStartError(f"Cold-start normalized verification changed {key}: {directory}")


def _validate_generic_parquet(path: Path, request: Mapping[str, object]) -> dict[str, object]:
    parquet = pq.ParquetFile(path)
    columns = tuple(parquet.schema_arrow.names)
    timestamp_column = next((name for name in ("ts_recv", "ts_event") if name in columns), None)
    if timestamp_column is None:
        raise ColdStartError("Normalized Databento Parquet has no event/receive timestamp")
    row_count = int(parquet.metadata.num_rows)
    if row_count < 1:
        raise ColdStartError("Normalized Databento Parquet is empty despite nonzero preflight count")
    earliest: pd.Timestamp | None = None
    latest: pd.Timestamp | None = None
    for batch in parquet.iter_batches(batch_size=250_000, columns=[timestamp_column]):
        column = batch.column(0)
        if len(column) == column.null_count:
            continue
        minimum = pd.to_datetime(pc.min(column).as_py(), utc=True, errors="coerce")
        maximum = pd.to_datetime(pc.max(column).as_py(), utc=True, errors="coerce")
        if not pd.isna(minimum):
            earliest = minimum if earliest is None else min(earliest, minimum)
        if not pd.isna(maximum):
            latest = maximum if latest is None else max(latest, maximum)
    if earliest is None or latest is None:
        raise ColdStartError("Normalized Databento Parquet has no valid timestamps")
    start = pd.Timestamp(str(request["start"]), tz="UTC")
    end = pd.Timestamp(str(request["end"]), tz="UTC")
    if earliest < start or latest >= end:
        raise ColdStartError("Normalized Databento timestamps escape the requested interval")
    return {
        "row_count": row_count,
        "columns": list(columns),
        "timestamp_column": timestamp_column,
        "earliest_timestamp": earliest.isoformat(),
        "latest_timestamp": latest.isoformat(),
    }


def _entry_storage_path(
    datastore_root: Path,
    *,
    dataset: str,
    market: str,
    schema: str,
    symbol: str,
    start: date,
    end: date,
    contract: str,
) -> Path:
    if contract == "canonical-opra":
        return (
            dataset_root(datastore_root, market=MARKET_OPRA, dataset=dataset)
            / _safe_token(schema)
            / _safe_token(symbol)
        )
    return request_directory(
        datastore_root,
        market=market,
        dataset=dataset,
        schema=schema,
        symbol=symbol,
        start=start,
        end=end,
    )


def _request_kwargs(request: Mapping[str, object]) -> dict[str, object]:
    return {
        "dataset": request["dataset"],
        "schema": request["schema"],
        "symbols": list(request["symbol_scope"]),
        "stype_in": request["stype_in"],
        "start": request["start"],
        "end": request["end"],
    }


def _progress_path(datastore_root: Path, manifest: Mapping[str, object]) -> Path:
    return coordinator_run_directory(
        datastore_root,
        as_of=str(manifest["as_of"]),
    ) / "progress.json"


def _write_request_cursor(
    datastore_root: Path,
    *,
    manifest_id: str,
    request: Mapping[str, object],
    status: str,
) -> Path:
    """Record completed request identity without becoming a live-loop cursor."""

    market = _market_for_plan_dataset(str(request["standard_plan_dataset"]))
    symbol = str(request["symbol_scope"][0])
    path = history_cursor_path(
        datastore_root,
        market=market,
        dataset=str(request["dataset"]),
        schema=str(request["schema"]),
        symbol=symbol,
    )
    preserve_native_stock_cursor = request.get("dataset") == "XNAS.ITCH" and request.get("schema") == "ohlcv-1m"
    previous = (_read_request_cursor(datastore_root, market=market,
        dataset=str(request["dataset"]), schema=str(request["schema"]), symbol=symbol)
        if preserve_native_stock_cursor else None)
    if previous is not None and _as_date(previous["completed_through"]) > _as_date(request["end"]):
        # Historical native backfills must not move the recurring owner backward.
        # Preserve only a cursor tied to complete, independently verified evidence.
        directory, _ = _generic_entry_paths(datastore_root, previous)
        manifest = _read_json_object(directory / "manifest.json", label="later cursor partition")
        prior_request = manifest.get("request")
        if (not isinstance(prior_request, Mapping)
                or prior_request.get("storage_contract") != "isolated-cold-start"
                or previous.get("status") not in {"PUBLISHED", "VERIFIED_EXISTING"}
                or previous.get("completed_through") != previous.get("end")
                or any(previous.get(key) != prior_request.get(key)
                       for key in ("request_id", "dataset", "schema", "symbol_scope", "start", "end", "fetch_mode"))):
            raise ColdStartError("Later history cursor has no verified native request identity")
        _validate_execution_request_identity(datastore_root, prior_request)
        if Path(str(prior_request["storage_path"])).resolve() != directory:
            raise ColdStartError("Later history cursor points to another native partition")
        for name in ("raw", "normalized"):
            info = manifest.get(name, {})
            if not isinstance(info, Mapping) or not (directory / str(info.get("path", ""))).resolve().is_relative_to(directory):
                raise ColdStartError("Later history cursor payload escapes its native partition")
        _verify_generic_partition(directory, prior_request)
        return path
    payload = {
        "schema_version": "databento-cold-start-request-cursor-v1",
        "manifest_id": manifest_id,
        "request_id": request["request_id"],
        "dataset": request["dataset"],
        "schema": request["schema"],
        "symbol_scope": list(request["symbol_scope"]),
        "start": request["start"],
        "end": request["end"],
        "completed_through": request["end"],
        "fetch_mode": request.get("fetch_mode", "initial-baseline"),
        "storage_path": request["storage_path"],
        "status": status,
        "completed_at": _utc_now().isoformat(),
    }
    _write_json_atomic(path, payload)
    return path


def _read_progress(path: Path, *, manifest_id: str) -> dict[str, object]:
    if not path.is_file():
        return {"schema_version": PROGRESS_VERSION, "manifest_id": manifest_id, "entries": {}}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ColdStartError(f"Cold-start progress is unreadable: {path}") from exc
    if payload.get("schema_version") != PROGRESS_VERSION or payload.get("manifest_id") != manifest_id:
        raise ColdStartError(f"Cold-start progress identity is invalid: {path}")
    if not isinstance(payload.get("entries"), dict):
        raise ColdStartError(f"Cold-start progress entries are invalid: {path}")
    return payload


def _update_progress(
    progress: dict[str, object], request: Mapping[str, object], *, status: str, details: Mapping[str, object]
) -> None:
    entries = progress["entries"]
    assert isinstance(entries, dict)
    entries[str(request["request_id"])] = {
        "dataset": request["dataset"],
        "schema": request["schema"],
        "symbol_scope": list(request["symbol_scope"]),
        "status": status,
        "updated_at": _utc_now().isoformat(),
        "details": dict(details),
    }


def _write_progress(path: Path, progress: Mapping[str, object]) -> None:
    _write_json_atomic(path, progress)


def _metadata_call(
    function: Callable[..., object],
    *,
    _retry_sleeper: Callable[[float], None] = time.sleep,
    **kwargs: object,
) -> object:
    attempts = 0

    def request() -> object:
        nonlocal attempts
        attempts += 1
        return function(**kwargs)

    try:
        return call_with_persistent_databento_retry(
            request,
            operation_name="metadata." + getattr(function, "__name__", "request"),
            sleep=_retry_sleeper,
        )
    except Exception as exc:
        raise ColdStartError(
            f"Databento metadata request failed after {attempts} attempt(s): "
            f"{type(exc).__name__}"
        ) from exc


def _window_start(end: date, policy: Mapping[str, object]) -> date:
    amount = int(policy["value"])
    if policy["unit"] == "days":
        return (pd.Timestamp(end) - pd.Timedelta(days=amount)).date()
    if policy["unit"] == "years":
        return (pd.Timestamp(end) - pd.DateOffset(years=amount)).date()
    if policy["unit"] in {"months", "calendar_months"}:
        return (pd.Timestamp(end) - pd.DateOffset(months=amount)).date()
    raise ColdStartError(f"Unsupported cold-start window policy: {policy}")


def _split_configured_symbols(value: str) -> tuple[str, ...]:
    text = str(value).strip()
    if not text:
        return ()
    if text.startswith("["):
        try:
            decoded = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ColdStartError("CME symbol configuration looks like malformed JSON") from exc
        if not isinstance(decoded, list) or not all(isinstance(item, str) for item in decoded):
            raise ColdStartError("CME JSON symbol configuration must be an array of strings")
        return tuple(item.strip() for item in decoded if item.strip())
    return tuple(part.strip() for part in re.split(r"[\s,;]+", text) if part.strip())


def _validate_cme_symbol(value: str) -> str:
    symbol = str(value).strip()
    if not symbol or not re.fullmatch(r"[A-Za-z0-9._+\-/]+", symbol):
        raise ColdStartError(f"Invalid explicit CME symbol/root: {value!r}")
    return symbol


def _as_date(value: object) -> date:
    parsed = pd.to_datetime(value, utc=True, errors="coerce")
    if pd.isna(parsed):
        raise ColdStartError(f"Invalid Databento date bound: {value!r}")
    return parsed.date()


def _parse_date(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("Use YYYY-MM-DD for --as-of") from exc


def _safe_token(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("._-") or "unknown"


def _market_for_plan_dataset(standard_plan_dataset: str) -> str:
    markets = {
        PLAN_DATASET_OPRA: MARKET_OPRA,
        PLAN_DATASET_CME: MARKET_CME,
        PLAN_DATASET_US_EQUITIES: MARKET_US_EQUITIES,
    }
    try:
        return markets[str(standard_plan_dataset)]
    except KeyError as exc:
        raise ColdStartError(
            f"Unsupported Databento Standard-plan market: {standard_plan_dataset!r}"
        ) from exc


def _overlap_days(schema: str) -> int:
    """Return a conservative whole-day overlap for a later coordinator run."""

    if schema.endswith("-1s"):
        return 1
    if schema.endswith("-1m"):
        return 2
    if schema.endswith("-1h"):
        return 5
    if schema.endswith("-1d"):
        return 10
    return 3


def _read_request_cursor(
    datastore_root: Path,
    *,
    market: str,
    dataset: str,
    schema: str,
    symbol: str,
) -> Mapping[str, object] | None:
    path = history_cursor_path(
        datastore_root,
        market=market,
        dataset=dataset,
        schema=schema,
        symbol=symbol,
    )
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ColdStartError(f"Databento history cursor is unreadable: {path}") from exc
    if (
        not isinstance(payload, Mapping)
        or payload.get("schema_version") != "databento-cold-start-request-cursor-v1"
        or payload.get("dataset") != dataset
        or payload.get("schema") != schema
        or payload.get("symbol_scope") != [symbol]
        or not payload.get("completed_through")
    ):
        raise ColdStartError(f"Databento history cursor identity is invalid: {path}")
    return payload


def _next_attempt_directory(base: Path) -> Path:
    for attempt in count(1):
        candidate = base / f"attempt-{attempt:03d}"
        if not candidate.exists():
            return candidate


def _checksum(value: object) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _write_json_exclusive(path: Path, payload: Mapping[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(dict(payload), handle, indent=2, sort_keys=True, default=str)
        handle.write("\n")


def _write_json_atomic(path: Path, payload: Mapping[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = _next_pending_file(path)
    _write_json_exclusive(temporary, payload)
    temporary.replace(path)


def _next_pending_file(path: Path) -> Path:
    for attempt in count(1):
        candidate = path.with_name(f"{path.name}.pending-{attempt:03d}")
        if not candidate.exists():
            return candidate


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _print_dry_run(manifest: Mapping[str, object]) -> None:
    print("DATABENTO COLD-START DRY RUN")
    print(f"Manifest: {manifest['manifest_id']}; requests={len(manifest['requests'])}")
    for item in manifest["requests"]:
        print(
            f"PENDING {item['dataset']} {item['schema']} {item['symbol_scope'][0]} "
            f"{item['start']}..{item['end']} -> {item['storage_path']}"
        )


def _print_preflight(
    manifest: Mapping[str, object],
    preflight: Mapping[str, object],
    *,
    manifest_path: Path,
    preflight_path: Path,
) -> None:
    print("DATABENTO COLD-START PREFLIGHT")
    print(f"Manifest: {manifest_path}")
    print(f"Preflight: {preflight_path}")
    for item in preflight["estimates"]:
        print(
            f"{item['dataset']} {item['schema']} {item['symbol_scope'][0]} "
            f"records={item['record_count']} "
            f"estimated_download_bytes={item['estimated_download_size_bytes']}"
        )
    print(
        "Totals: "
        f"records={preflight['total_record_count']} "
        f"estimated_download_bytes="
        f"{preflight['total_estimated_download_size_bytes']} "
        f"required_free_bytes={preflight['required_free_bytes']} "
        f"available_free_bytes={preflight['available_free_bytes']} "
        f"capacity_pass={preflight['capacity_pass']}"
    )


__all__ = [
    "CME_SCHEMAS",
    "OPRA_SCHEMAS",
    "US_EQUITIES_SCHEMAS",
    "ColdStartError",
    "CmeScope",
    "build_manifest",
    "discover_dataset_catalog",
    "execute_manifest",
    "latest_common_available_date",
    "load_execution_manifest",
    "load_execution_preflight",
    "main",
    "opra_parent_symbols",
    "parse_watchlist",
    "preflight_manifest",
    "required_free_bytes",
    "resolve_cme_scopes",
    "resolve_equities_dataset",
    "schema_window",
    "standard_plan_history_policy",
    "write_manifest",
]


if __name__ == "__main__":
    raise SystemExit(main())
